import { Link } from "@tanstack/react-router";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { PRESET_OPTIONS, rangeFor, type PresetKey } from "@/lib/datePresets";

const tabs = [
  { to: "/", label: "Overview" },
  { to: "/day-comparison", label: "Same vs Different Day" },
  { to: "/tl", label: "Under TL" },
  { to: "/trainers", label: "Trainer Counts" },
  { to: "/mails", label: "Email Activity" },
];

export function DashboardShell({
  children,
  lastUpdated,
  loading,
  onReload,
}: {
  children: React.ReactNode;
  lastUpdated: Date | null;
  loading: boolean;
  onReload: () => void;
}) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white">
        <div className="mx-auto max-w-7xl px-6 py-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Trainer Corrections — Live Dashboard
            </h1>
            <p className="text-sm text-slate-500">
              {lastUpdated
                ? `Updated ${lastUpdated.toLocaleTimeString()} · auto-refreshes every 60s`
                : "Loading live data…"}
            </p>
          </div>
          <button
            onClick={onReload}
            className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
            disabled={loading}
          >
            {loading ? "Refreshing…" : "Refresh now"}
          </button>
        </div>
        <nav className="mx-auto max-w-7xl px-6 pb-2 flex flex-wrap gap-1">
          {tabs.map((t) => (
            <Link
              key={t.to}
              to={t.to}
              activeOptions={{ exact: true }}
              className="rounded-md px-3 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-100"
              activeProps={{ className: "rounded-md px-3 py-1.5 text-sm font-medium bg-indigo-600 text-white" }}
            >
              {t.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-6 py-6 space-y-6">{children}</main>
    </div>
  );
}

export function DateRangePicker({
  from,
  to,
  onChange,
}: {
  from: Date | undefined;
  to: Date | undefined;
  onChange: (from: Date | undefined, to: Date | undefined) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <select
        onChange={(e) => {
          const { from: f, to: t } = rangeFor(e.target.value as PresetKey);
          onChange(f, t);
        }}
        className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        defaultValue="all"
      >
        {PRESET_OPTIONS.map((o) => (
          <option key={o.key} value={o.key}>{o.label}</option>
        ))}
      </select>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn("justify-start text-left font-normal", !from && "text-muted-foreground")}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {from ? format(from, "PP") : <span>From date</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar mode="single" selected={from} onSelect={(d) => onChange(d, to)} initialFocus className={cn("p-3 pointer-events-auto")} />
        </PopoverContent>
      </Popover>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn("justify-start text-left font-normal", !to && "text-muted-foreground")}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {to ? format(to, "PP") : <span>To date</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar mode="single" selected={to} onSelect={(d) => onChange(from, d)} initialFocus className={cn("p-3 pointer-events-auto")} />
        </PopoverContent>
      </Popover>
      {(from || to) && (
        <Button variant="ghost" size="sm" onClick={() => onChange(undefined, undefined)}>
          Clear
        </Button>
      )}
    </div>
  );
}

export function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-lg bg-white p-4 shadow-sm border border-slate-200">
      <div className={`inline-block h-1 w-8 rounded-full ${color} mb-2`} />
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-3xl font-bold text-slate-900">{value.toLocaleString()}</p>
    </div>
  );
}

export function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg bg-white p-4 shadow-sm border border-slate-200">
      <h3 className="mb-3 text-sm font-semibold text-slate-700">{title}</h3>
      {children}
    </div>
  );
}
