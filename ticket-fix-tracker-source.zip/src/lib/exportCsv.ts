import type { Row } from "./useCorrections";

function esc(v: string | number): string {
  const s = String(v ?? "");
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function download(filename: string, csv: string) {
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function downloadCsv(name: string, headers: string[], rows: (string | number)[][]) {
  const lines = [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))];
  download(`${name}_${new Date().toISOString().slice(0, 10)}.csv`, lines.join("\n"));
}

export function exportByTl(rows: Row[]) {
  const map = new Map<string, Row[]>();
  rows.forEach((r) => {
    const k = r.tl || "— Unassigned —";
    if (!map.has(k)) map.set(k, []);
    map.get(k)!.push(r);
  });
  const lines: string[] = ["TL Name,Trainer Email,Ticket ID,Timestamp,Corrected Date,Field,Incorrect,Correct,Zone,Reason"];
  Array.from(map.entries())
    .sort((a, b) => b[1].length - a[1].length)
    .forEach(([tl, list]) => {
      list.forEach((r) => {
        lines.push([tl, r.email, r.ticket, r.timestamp, r.correctedDate, r.field, r.incorrect, r.correct, r.zone, r.reason].map(esc).join(","));
      });
    });
  download(`corrections_by_tl_${new Date().toISOString().slice(0, 10)}.csv`, lines.join("\n"));
}

export function exportByZone(rows: Row[]) {
  const map = new Map<string, Row[]>();
  rows.forEach((r) => {
    const k = r.zone || "— No Zone —";
    if (!map.has(k)) map.set(k, []);
    map.get(k)!.push(r);
  });
  const lines: string[] = ["Zone,TL,Trainer Email,Ticket ID,Timestamp,Corrected Date,Field,Incorrect,Correct,Reason"];
  Array.from(map.entries())
    .sort((a, b) => b[1].length - a[1].length)
    .forEach(([zone, list]) => {
      list.forEach((r) => {
        lines.push([zone, r.tl, r.email, r.ticket, r.timestamp, r.correctedDate, r.field, r.incorrect, r.correct, r.reason].map(esc).join(","));
      });
    });
  download(`corrections_by_zone_${new Date().toISOString().slice(0, 10)}.csv`, lines.join("\n"));
}

export function exportRows(rows: Row[], name: string) {
  const lines: string[] = [
    "Timestamp,Email Address,Ticket Details,Ticket Corrected Date,Field to be Corrected,Incorrect Value Entered,Correct Value to be Updated,Reason for Correction,Zone,Under TL Name,Day Difference,Same Day",
  ];
  rows.forEach((r) => {
    lines.push(
      [r.timestamp, r.email, r.ticket, r.correctedDate, r.field, r.incorrect, r.correct, r.reason, r.zone, r.tl, r.dayDiff, r.sameDay ? "Yes" : "No"]
        .map(esc)
        .join(","),
    );
  });
  download(`${name}_${new Date().toISOString().slice(0, 10)}.csv`, lines.join("\n"));
}
