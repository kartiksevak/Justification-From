import { createServerFn } from "@tanstack/react-start";
import Papa from "papaparse";

const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";
const PUBLIC_CSV = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRtYTBgUEA5H2nUyAGCfAmLQdWkruu52Aw_X1oKhaTblr3M6OdVC_6QKxR_XHwjckLC2yj-4fIyYABP/pub?gid=1283717875&single=true&output=csv";
const GMAIL_GATEWAY = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";
const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 504]);

const b64 = (s: string) =>
  btoa(Array.from(new TextEncoder().encode(s), (b) => String.fromCharCode(b)).join(""));
const mimeHeader = (v: string) => (/^[\x00-\x7F]*$/.test(v) ? v : `=?UTF-8?B?${b64(v)}?=`);

function esc(s: string) {
  return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

type Change = { field: string; previousValue?: string; newValue: string };


async function sendTrainerMail(p: {
  to: string;
  cc?: string;
  ticket: string;
  timestamp: string;
  changes: Change[];
  remark?: string;
}) {
  const lovKey = process.env.LOVABLE_API_KEY;
  const mailKey = process.env.GOOGLE_MAIL_API_KEY;
  if (!lovKey || !mailKey) throw new Error("Gmail connection not configured");
  if (!p.to || !p.to.includes("@")) throw new Error("No valid trainer email on this row");

  const cc = (p.cc || "")
    .split(/[,;]+/)
    .map((s) => s.trim())
    .filter((s) => s.includes("@"))
    .join(", ");
  const subject = `Correction Update - Ticket ${p.ticket}`;
  const cell = "padding:8px 10px;border-top:1px solid #e2e8f0";
  const rows = p.changes
    .map(
      (c) => `
        <tr>
          <td style="${cell}"><b>${esc(c.field)}</b></td>
          <td style="${cell};color:#64748b">${esc(c.previousValue ?? "") || "<i>Not filled</i>"}</td>
          <td style="${cell};color:#047857"><b>${esc(c.newValue) || "<i>Cleared</i>"}</b></td>
        </tr>`,
    )
    .join("");
  const remarkHtml = `
      <p style="margin:16px 0 4px"><b>Reviewer Remark:</b></p>
      <p style="margin:0;padding:10px 12px;background:#fefce8;border-left:3px solid #eab308"><b>${esc(p.remark || "-")}</b></p>`;
  const html = `
    <div style="font-family:Arial,sans-serif;font-size:14px;color:#0f172a;line-height:1.5">
      <p>Dear Trainer,</p>
      <p>Your correction form for <b>Ticket ${esc(p.ticket)}</b> (submitted on ${esc(p.timestamp)}) has been reviewed and updated.</p>
      <table cellspacing="0" style="border-collapse:collapse;font-size:14px;border:1px solid #e2e8f0">
        <tr style="background:#f1f5f9">
          <th align="left" style="padding:8px 10px">What was updated</th>
          <th align="left" style="padding:8px 10px">Before</th>
          <th align="left" style="padding:8px 10px">After review</th>
        </tr>
        ${rows}
      </table>
      ${remarkHtml}
      <p style="margin-top:16px">If you have any questions, please reply to this email.</p>
      <p>Thanks &amp; Regards,<br>Kartik Sevak<br>Quality Check</p>
    </div>`;

  const lines = [`To: ${p.to}`];
  if (cc) lines.push(`Cc: ${cc}`);
  lines.push(
    `Subject: ${mimeHeader(subject)}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "",
    html,
  );
  const raw = lines.join("\r\n");

  const encoded = b64(raw).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

  const res = await fetch(`${GMAIL_GATEWAY}/users/me/messages/send`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovKey}`,
      "X-Connection-Api-Key": mailKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ raw: encoded }),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Gmail [${res.status}]: ${body}`);
  }
  return res.json();
}

// Send a custom revert email (composed in the dashboard) directly via Gmail
type RevertMail = { to: string; cc?: string; subject: string; body: string; remark: string };

async function sendRevertMail(data: RevertMail) {
    const lovKey = process.env.LOVABLE_API_KEY;
    const mailKey = process.env.GOOGLE_MAIL_API_KEY;
    if (!lovKey || !mailKey) throw new Error("Gmail connection not configured");
    if (!data.to || !data.to.includes("@")) throw new Error("No valid trainer email on this row");

    const cc = (data.cc || "")
      .split(/[,;]+/)
      .map((s) => s.trim())
      .filter((s) => s.includes("@"))
      .join(", ");

    const escapedBody = esc(data.body);
    const remarkLine = `Reviewer Remark: ${data.remark || "-"}`;
    const htmlBody = escapedBody
      .replace(esc(remarkLine), `Reviewer Remark: <strong>${esc(data.remark || "-")}</strong>`)
      .replace(/\n/g, "<br>");

    const lines = [`To: ${data.to}`];
    if (cc) lines.push(`Cc: ${cc}`);
    lines.push(
      `Subject: ${mimeHeader(data.subject)}`,
      "MIME-Version: 1.0",
      'Content-Type: text/html; charset="UTF-8"',
      "",
      `<div style="font-family:Arial,sans-serif;font-size:14px;color:#0f172a;line-height:1.55">${htmlBody}</div>`,
    );

    const encoded = b64(lines.join("\r\n")).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    let lastError = "Email could not be sent";
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await fetch(`${GMAIL_GATEWAY}/users/me/messages/send`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${lovKey}`,
            "X-Connection-Api-Key": mailKey,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ raw: encoded }),
        });
        if (res.ok) return { ok: true, cc };
        const responseBody = await res.text();
        lastError = `Gmail [${res.status}]: ${responseBody}`;
        if (!RETRYABLE_STATUS.has(res.status)) break;
      } catch (error) {
        lastError = error instanceof Error ? error.message : String(error);
      }
      await new Promise((resolve) => setTimeout(resolve, 700));
    }
    console.error(`Revert email failed: ${lastError}`);
    throw new Error(lastError);
}

export const sendRevertEmail = createServerFn({ method: "POST" })
  .inputValidator((d: RevertMail) => d)
  .handler(async ({ data }) => sendRevertMail(data));

// Column letter helper
function colLetter(n: number): string {
  let s = "";
  n = n + 1;
  while (n > 0) {
    const rem = (n - 1) % 26;
    s = String.fromCharCode(65 + rem) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

type UpdatePayload = {
  ticket: string;
  timestamp: string;
  email: string;
  field: string; // header name in the sheet to update
  value: string;
  notify?: boolean; // default true — email the trainer about this update
  changes?: Change[]; // optional full change list for one combined email
  remark?: string;
};


async function gwFetchOnce(path: string, init?: RequestInit) {
  const lovKey = process.env.LOVABLE_API_KEY;
  const connKey = process.env.GOOGLE_SHEETS_API_KEY;
  if (!lovKey || !connKey) throw new Error("Google Sheets connection not configured");
  const res = await fetch(GATEWAY + path, {
    ...init,
    headers: {
      "Authorization": `Bearer ${lovKey}`,
      "X-Connection-Api-Key": connKey,
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Google Sheets [${res.status}]: ${body}`);
  }
  return res.json();
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Sheets has a per-minute read quota. Retry temporary failures (429/5xx) with
// backoff, honoring Retry-After when Google provides it; never retry 4xx.
async function gwFetch(path: string, init?: RequestInit) {
  let lastError: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await gwFetchOnce(path, init);
    } catch (error) {
      lastError = error;
      const message = error instanceof Error ? error.message : String(error);
      const match = message.match(/Google Sheets \[(\d+)\]/);
      const status = match ? Number(match[1]) : 0;
      if (!RETRYABLE_STATUS.has(status)) break;
      const retryAfter = Number(message.match(/retry-after: (\d+)/i)?.[1] ?? 0);
      await sleep(Math.max(retryAfter * 1000, 1000 * Math.pow(2, attempt)));
    }
  }
  throw lastError;
}

// One-shot revert: read the sheet once, write all fields in a single batch, then send the mail.
export const saveRevertAndSend = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      ticket: string;
      timestamp: string;
      email: string;
      fields: { field: string; value: string }[];
      mail: { to: string; cc?: string; subject: string; body: string; remark: string };
      status?: "done" | "not";
      previousStatus?: string;
    }) => d,
  )
  .handler(async ({ data }) => {
    // Exactly one mail per action: Done -> short update mail (with remark),
    // Not Done -> full detailed mail so the trainer can fix and reply.
    // Mail is independent of the sheet so a sheet failure never blocks it.
    const statusField = data.fields.find((f) => f.field === "Checked Status");
    const mailPromise = data.status === "done"
      ? sendTrainerMail({
          to: data.mail.to,
          cc: data.mail.cc,
          ticket: data.ticket,
          timestamp: data.timestamp,
          remark: data.mail.remark,
          changes: [{ field: "Checked Status", previousValue: data.previousStatus ?? "", newValue: statusField?.value ?? "Done" }],
        })
      : sendRevertMail(data.mail);
    let matchRow = -1;

    const sheetPromise = (async () => {
      const sheetId = "1QEz_EmQZnFU4WTjUc8_SddJNb8-6m-CgKxUgvZDUqkk";
      const tabName = "Form Responses ";
      if (!sheetId || !tabName) throw new Error("Correction sheet is not configured");
      const quoted = `'${tabName.replace(/'/g, "''")}'`;

      let values: string[][] = [];
      let usedTab = quoted;
      let lastErr: unknown = null;
      // Find the row via the published CSV first: it has no read quota, so a
      // Sheets 429 can no longer block the save. Empty lines are kept so CSV
      // line N == sheet row N.
      try {
        const res = await fetch(`${PUBLIC_CSV}&_=${Date.now()}`);
        if (!res.ok) throw new Error(`Published sheet [${res.status}]`);
        values = Papa.parse<string[]>(await res.text(), { skipEmptyLines: false }).data;
      } catch (e) {
        lastErr = e;
      }
      if (values.length === 0) {
        for (const t of [quoted, `'${tabName.trim().replace(/'/g, "''")}'`]) {
          try {
            const r = await gwFetch(`/spreadsheets/${sheetId}/values/${encodeURIComponent(`${t}!A1:Z10000`)}`);
            values = r.values ?? [];
            usedTab = t;
            lastErr = null;
            break;
          } catch (e) {
            lastErr = e;
          }
        }
      }
      if (lastErr && values.length === 0) throw lastErr;
      if (values.length === 0) throw new Error("Sheet is empty");
      const headers = values[0].map((h) => (h || "").trim());
      const idx = (name: string) => headers.findIndex((h) => h.toLowerCase() === name.toLowerCase());
      const cTs = idx("Timestamp");
      const cTicket = idx("Ticket Details");
      const cEmail = idx("Email Address");
      const norm = (s: string) => (s || "").trim().replace(/\s+/g, " ").toLowerCase();

      const candidates: number[] = [];
      for (let i = 1; i < values.length; i++) {
        const row = values[i] ?? [];
        if (norm(row[cTicket]) === norm(data.ticket) && norm(row[cEmail]) === norm(data.email)) {
          candidates.push(i);
          if (norm(row[cTs]) === norm(data.timestamp)) {
            matchRow = i + 1;
            break;
          }
        }
      }
      if (matchRow < 0 && candidates.length === 1) matchRow = candidates[0] + 1;
      if (matchRow < 0) throw new Error("Matching row not found in sheet (ticket/timestamp/email)");

      const rangeData = data.fields.map((f) => {
        const c = idx(f.field);
        if (c < 0) throw new Error(`Column not found in sheet: ${f.field}`);
        return { range: `${usedTab}!${colLetter(c)}${matchRow}`, values: [[f.value]] };
      });
      return gwFetch(`/spreadsheets/${sheetId}/values:batchUpdate`, {
        method: "POST",
        body: JSON.stringify({ valueInputOption: "USER_ENTERED", data: rangeData }),
      });
    })();

    const [sheetResult, mailResult] = await Promise.allSettled([sheetPromise, mailPromise]);

    const sheetError = sheetResult.status === "rejected"
      ? (sheetResult.reason instanceof Error ? sheetResult.reason.message : String(sheetResult.reason))
      : null;
    const mailError = mailResult.status === "rejected"
      ? (mailResult.reason instanceof Error ? mailResult.reason.message : String(mailResult.reason))
      : null;
    return {
      ok: !sheetError && !mailError,
      row: matchRow,
      sheetSaved: !sheetError,
      emailSent: !mailError,
      sheetError,
      mailError,
    };
  });

export const updateCorrectionCell = createServerFn({ method: "POST" })
  .inputValidator((d: UpdatePayload) => d)
  .handler(async ({ data }) => {
    const sheetId = "1QEz_EmQZnFU4WTjUc8_SddJNb8-6m-CgKxUgvZDUqkk";
    const tabName = "Form Responses ";
    if (!sheetId || !tabName) throw new Error("Correction sheet is not configured");

    // Find the row via the published CSV first (no read quota); the Sheets
    // API is only a fallback so a 429 cannot block a Done mark.
    let values: string[][] = [];
    try {
      const res = await fetch(`${PUBLIC_CSV}&_=${Date.now()}`);
      if (!res.ok) throw new Error(`Published sheet [${res.status}]`);
      values = Papa.parse<string[]>(await res.text(), { skipEmptyLines: false }).data;
    } catch {
      values = [];
    }
    if (values.length === 0) {
      const readUrl = `/spreadsheets/${sheetId}/values/${encodeURIComponent(tabName)}!A1:Z10000`;
      const readResp = await gwFetch(readUrl);
      values = readResp.values ?? [];
    }
    if (values.length === 0) throw new Error("Sheet is empty");
    const headers = values[0].map((h) => (h || "").trim());

    // Locate columns
    const idx = (name: string) => headers.findIndex((h) => h.toLowerCase() === name.toLowerCase());
    const cTs = idx("Timestamp");
    const cTicket = idx("Ticket Details");
    const cEmail = idx("Email Address");
    const cField = idx(data.field);
    if (cField < 0) throw new Error(`Column not found in sheet: ${data.field}`);

    // Find the matching row (skip header). Timestamp formatting can differ
    // slightly, so fall back to ticket + email when there is exactly one match.
    const norm = (s: string) => (s || "").trim().replace(/\s+/g, " ").toLowerCase();
    let matchRow = -1;
    const candidates: number[] = [];
    for (let i = 1; i < values.length; i++) {
      const row = values[i] ?? [];
      if (norm(row[cTicket]) === norm(data.ticket) && norm(row[cEmail]) === norm(data.email)) {
        candidates.push(i);
        if (norm(row[cTs]) === norm(data.timestamp)) {
          matchRow = i + 1; // 1-indexed row in sheet
          break;
        }
      }
    }
    if (matchRow < 0 && candidates.length === 1) matchRow = candidates[0] + 1;
    if (matchRow < 0) throw new Error("Matching row not found in sheet (ticket/timestamp/email)");

    const targetRange = `${tabName}!${colLetter(cField)}${matchRow}`;
    const previousValue = (values[matchRow - 1]?.[cField] ?? "").trim();

    const writePath = `/spreadsheets/${sheetId}/values/${encodeURIComponent(targetRange)}?valueInputOption=USER_ENTERED`;
    await gwFetch(writePath, {
      method: "PUT",
      body: JSON.stringify({ values: [[data.value]] }),
    });

    let mailed = false;
    let mailError: string | null = null;
    if (data.notify !== false) {
      try {
        await sendTrainerMail({
          to: data.email,
          ticket: data.ticket,
          timestamp: data.timestamp,
          remark: data.remark,
          changes:
            data.changes && data.changes.length > 0
              ? data.changes
              : [{ field: data.field, previousValue, newValue: data.value }],
        });
        mailed = true;
      } catch (e) {
        mailError = e instanceof Error ? e.message : String(e);
        console.error("Trainer mail failed:", mailError);
      }
    }

    return { ok: true, range: targetRange, row: matchRow, mailed, mailError };
  });


