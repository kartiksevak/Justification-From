export type MarkDoneEntry = {
  ticket: string;
  email: string;
  field: string;
  at: string;
};

const KEY = "mark-done-log";
const MAX = 200;

export function readMarkDoneLog(): MarkDoneEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    const list = raw ? (JSON.parse(raw) as MarkDoneEntry[]) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function logMarkDone(entry: Omit<MarkDoneEntry, "at">) {
  if (typeof window === "undefined") return;
  try {
    const list = readMarkDoneLog();
    list.unshift({ ...entry, at: new Date().toISOString() });
    window.localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
  } catch {
    // storage full or blocked — ignore
  }
}
