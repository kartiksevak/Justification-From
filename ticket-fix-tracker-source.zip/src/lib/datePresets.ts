export type PresetKey = "today" | "yesterday" | "this_week" | "last_week" | "this_month" | "last_month" | "all";

export const PRESET_OPTIONS: { key: PresetKey; label: string }[] = [
  { key: "all", label: "All time" },
  { key: "today", label: "Today" },
  { key: "yesterday", label: "Yesterday" },
  { key: "this_week", label: "This week" },
  { key: "last_week", label: "Last week" },
  { key: "this_month", label: "This month" },
  { key: "last_month", label: "Last month" },
];

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function startOfWeek(d: Date) {
  const x = startOfDay(d);
  const day = x.getDay(); // Sun=0
  const diff = (day + 6) % 7; // Monday as week start
  x.setDate(x.getDate() - diff);
  return x;
}
function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

export function rangeFor(key: PresetKey): { from: Date | undefined; to: Date | undefined } {
  const now = new Date();
  if (key === "all") return { from: undefined, to: undefined };
  if (key === "today") return { from: startOfDay(now), to: startOfDay(now) };
  if (key === "yesterday") {
    const y = addDays(startOfDay(now), -1);
    return { from: y, to: y };
  }
  if (key === "this_week") {
    const s = startOfWeek(now);
    return { from: s, to: startOfDay(now) };
  }
  if (key === "last_week") {
    const s = addDays(startOfWeek(now), -7);
    return { from: s, to: addDays(s, 6) };
  }
  if (key === "this_month") {
    const s = new Date(now.getFullYear(), now.getMonth(), 1);
    return { from: s, to: startOfDay(now) };
  }
  if (key === "last_month") {
    const s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const e = new Date(now.getFullYear(), now.getMonth(), 0);
    return { from: s, to: e };
  }
  return { from: undefined, to: undefined };
}
