import { createServerFn } from "@tanstack/react-start";
import Papa from "papaparse";

const SHEETS_GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";
const PUBLIC_CSV = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRtYTBgUEA5H2nUyAGCfAmLQdWkruu52Aw_X1oKhaTblr3M6OdVC_6QKxR_XHwjckLC2yj-4fIyYABP/pub?gid=1283717875&single=true&output=csv";
const PUBLIC_HTML = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRtYTBgUEA5H2nUyAGCfAmLQdWkruu52Aw_X1oKhaTblr3M6OdVC_6QKxR_XHwjckLC2yj-4fIyYABP/pubhtml?gid=1283717875&single=true";

let cachedValues: string[][] | null = null;
let fetchedAt = 0;
let pendingRead: Promise<string[][]> | null = null;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 504]);
const CACHE_TTL_MS = 45_000; // absorb the 60s client polls + multiple tabs into one Sheets read

async function readPublishedCsv() {
  const response = await fetch(`${PUBLIC_CSV}&_=${Date.now()}`, {
    headers: { Accept: "text/csv" },
  });
  if (!response.ok) throw new Error(`Published sheet [${response.status}]`);
  const parsed = Papa.parse<string[]>(await response.text(), { skipEmptyLines: true });
  if (parsed.data.length === 0) throw new Error("Published sheet returned no rows");
  return parsed.data;
}

function decodeHtmlEntities(text: string): string {
  return text
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

// Last-resort fallback: parse the published sheet's HTML view (pubhtml) when
// both the Sheets API and the CSV export are unavailable.
async function readPublishedHtml(): Promise<string[][]> {
  const response = await fetch(`${PUBLIC_HTML}?_=${Date.now()}`, {
    headers: { Accept: "text/html" },
  });
  if (!response.ok) throw new Error(`Published HTML sheet [${response.status}]`);
  const html = await response.text();
  const rows: string[][] = [];
  const rowMatches = html.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) ?? [];
  for (const rowHtml of rowMatches) {
    const cells: string[] = [];
    const cellMatches = rowHtml.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi) ?? [];
    for (const cellHtml of cellMatches) {
      const inner = cellHtml.replace(/<\/?t[dh][^>]*>/gi, "");
      cells.push(decodeHtmlEntities(inner.replace(/<[^>]+>/g, "")).trim());
    }
    if (cells.length > 0 && cells.some((c) => c !== "")) rows.push(cells);
  }
  if (rows.length === 0) throw new Error("Published HTML sheet returned no rows");
  return rows;
}

// Sheets has a per-minute read quota: retry temporary failures (429/5xx) with
// backoff, honoring Retry-After; never retry ordinary 4xx errors.
async function fetchWithRetry(url: string, headers: Record<string, string>): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetch(url, { headers });
      if (response.ok) return response;
      const body = await response.text().catch(() => "");
      if (!RETRYABLE_STATUS.has(response.status)) {
        throw new Error(`Sheet read failed [${response.status}]: ${body}`);
      }
      lastError = new Error(`Google Sheets [${response.status}]: ${body}`);
      const retryAfter = Number(response.headers.get("retry-after") ?? 0);
      await sleep(Math.max(retryAfter * 1000, 1000 * Math.pow(2, attempt)));
    } catch (error) {
      // Network errors from fetch itself also deserve one retry cycle.
      lastError = error;
      const message = error instanceof Error ? error.message : String(error);
      if (/Sheet read failed/.test(message)) throw error;
      await sleep(1000 * Math.pow(2, attempt));
    }
  }
  throw lastError;
}

async function readFromSheetsApi(): Promise<string[][]> {
  const lovableKey = process.env.LOVABLE_API_KEY;
  const sheetsKey = process.env.GOOGLE_SHEETS_API_KEY;
  const sheetId = "1QEz_EmQZnFU4WTjUc8_SddJNb8-6m-CgKxUgvZDUqkk";
  const tabName = "Form Responses ";
  if (!lovableKey || !sheetsKey || !sheetId || !tabName) throw new Error("Google Sheets connection not configured");

  const headers = {
    Authorization: `Bearer ${lovableKey}`,
    "X-Connection-Api-Key": sheetsKey,
  };
  const readRange = (title: string) => {
    const range = `'${title.replace(/'/g, "''")}'!A1:Z10000`;
    return `${SHEETS_GATEWAY}/spreadsheets/${encodeURIComponent(sheetId.trim())}/values/${range.replace(/ /g, "%20")}?majorDimension=ROWS`;
  };

  let response = await fetchWithRetry(readRange(tabName), headers);
  if (response.status === 404 && tabName !== tabName.trim()) {
    response = await fetchWithRetry(readRange(tabName.trim()), headers);
  }
  if (!response.ok) {
    const body = await response.text().catch(() => "");
    console.error(`Google Sheets reload failed [${response.status}]: ${body}`);
    throw new Error(`Google Sheets [${response.status}]`);
  }
  const payload = (await response.json()) as { values?: string[][] };
  if (!payload.values || payload.values.length === 0) throw new Error("Sheet returned no rows");
  return payload.values;
}

export const getCorrectionValues = createServerFn({ method: "GET" }).handler(async () => {
  // Dedupe concurrent calls and serve a recent read: one read per TTL window
  // keeps the Sheets read quota (429 RESOURCE_EXHAUSTED) from tripping.
  if (cachedValues && Date.now() - fetchedAt < CACHE_TTL_MS) {
    return { values: cachedValues };
  }
  if (!pendingRead) {
    pendingRead = (async () => {
      // The published CSV has no quota; the Sheets API shares a per-minute read
      // quota across every app on this Google Cloud project (429 RESOURCE_EXHAUSTED).
      try {
        const values = await readPublishedCsv();
        cachedValues = values;
        fetchedAt = Date.now();
        return values;
      } catch (csvError) {
        console.error("Published CSV read failed, trying Sheets API:", csvError);
        try {
          const values = await readFromSheetsApi();
          cachedValues = values;
          fetchedAt = Date.now();
          return values;
        } catch (error) {
          console.error("Google Sheets read failed, falling back to published HTML:", error);
          try {
            const values = await readPublishedHtml();
            cachedValues = values;
            fetchedAt = Date.now();
            return values;
          } catch (htmlError) {
            console.error("Published HTML sheet fallback failed:", htmlError);
            // A temporary provider failure must not turn the dashboard into an error page.
            return cachedValues ?? [];
          }
        }
      } finally {
        pendingRead = null;
      }
    })();
  }
  const values = await pendingRead;
  return { values };
});
