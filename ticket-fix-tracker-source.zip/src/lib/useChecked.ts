import { useCallback, useEffect, useState } from "react";
import type { Row } from "./useCorrections";

const STORAGE_KEY = "corrections_checked_v1";

export function rowKey(r: Row): string {
  return `${r.ticket}||${r.timestamp}||${r.email}`;
}

function readLocal(): Record<string, boolean> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

/** Local (this-browser) checked marks, merged on top of the sheet value. */
export function useCheckedLocal() {
  const [local, setLocal] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setLocal(readLocal());
  }, []);

  const setChecked = useCallback((r: Row, value: boolean) => {
    setLocal((prev) => {
      const next = { ...prev, [rowKey(r)]: value };
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const isChecked = useCallback(
    (r: Row) => {
      const l = local[rowKey(r)];
      if (l !== undefined) return l;
      return r.checked;
    },
    [local],
  );

  return { isChecked, setChecked };
}
