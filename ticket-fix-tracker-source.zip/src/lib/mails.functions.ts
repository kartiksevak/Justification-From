import { createServerFn } from "@tanstack/react-start";

const GMAIL = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";

export type MailItem = {
  id: string;
  threadId: string;
  direction: "sent" | "reply";
  from: string;
  to: string;
  cc: string;
  subject: string;
  date: string;
  snippet: string;
};

async function gmail(path: string) {
  const lovKey = process.env.LOVABLE_API_KEY;
  const mailKey = process.env.GOOGLE_MAIL_API_KEY;
  if (!lovKey || !mailKey) throw new Error("Gmail connection not configured");
  const res = await fetch(GMAIL + path, {
    headers: { Authorization: `Bearer ${lovKey}`, "X-Connection-Api-Key": mailKey },
  });
  if (!res.ok) throw new Error(`Gmail [${res.status}]: ${await res.text()}`);
  return res.json();
}

function header(msg: any, name: string): string {
  const h = (msg?.payload?.headers ?? []).find(
    (x: any) => (x.name || "").toLowerCase() === name.toLowerCase(),
  );
  return h?.value ?? "";
}

async function fetchList(q: string, direction: "sent" | "reply", max: number): Promise<MailItem[]> {
  const list = await gmail(
    `/users/me/messages?maxResults=${max}&q=${encodeURIComponent(q)}`,
  );
  const ids: string[] = (list.messages ?? []).map((m: any) => m.id);
  if (ids.length === 0) return [];
  const msgs: any[] = [];
  for (let offset = 0; offset < ids.length; offset += 5) {
  const boundary = `mail_batch_${crypto.randomUUID()}`;
  const body = ids.slice(offset, offset + 5).map((id) => [
    `--${boundary}`, "Content-Type: application/http", "",
    `GET /gmail/v1/users/me/messages/${id}?format=metadata&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Cc&metadataHeaders=Subject&metadataHeaders=Date`, "",
  ].join("\r\n")).join("\r\n") + `\r\n--${boundary}--\r\n`;
  const lovKey = process.env.LOVABLE_API_KEY;
  const mailKey = process.env.GOOGLE_MAIL_API_KEY;
  if (!lovKey || !mailKey) throw new Error("Gmail connection not configured");
  const response = await fetch("https://connector-gateway.lovable.dev/google_mail/batch/gmail/v1", {
    method: "POST",
    headers: { Authorization: `Bearer ${lovKey}`, "X-Connection-Api-Key": mailKey, "Content-Type": `multipart/mixed; boundary=${boundary}` },
    body,
  });
  if (!response.ok) throw new Error(`Gmail [${response.status}]: ${await response.text()}`);
  const contentType = response.headers.get("content-type") ?? "";
  const responseBoundary = contentType.match(/boundary="?([^";\s]+)/i)?.[1];
  if (!contentType.toLowerCase().includes("multipart/mixed") || !responseBoundary) throw new Error("Gmail returned an invalid batch response");
  const batchMessages = (await response.text()).split(`--${responseBoundary}`).slice(1).filter((part) => part.includes("HTTP/")).map((part) => {
    const httpStart = part.indexOf("HTTP/");
    const http = part.slice(httpStart).replace(/\r\n/g, "\n");
    const status = Number(http.match(/^HTTP\/\S+\s+(\d+)/)?.[1]);
    const split = http.indexOf("\n\n");
    const json = http.slice(split + 2).trim();
    if (status < 200 || status >= 300 || split < 0) throw new Error(`Gmail message read failed [${status}]: ${json}`);
    return JSON.parse(json);
  });
  msgs.push(...batchMessages);
  }
  return msgs
    .filter(Boolean)
    .map((m: any) => ({
      id: m.id,
      threadId: m.threadId,
      direction,
      from: header(m, "From"),
      to: header(m, "To"),
      cc: header(m, "Cc"),
      subject: header(m, "Subject"),
      date: header(m, "Date"),
      snippet: m.snippet ?? "",
    }));
}

let mailCache: { mails: MailItem[]; at: number } | null = null;
let pendingMails: Promise<{ mails: MailItem[] }> | null = null;

async function readCorrectionMails() {
  const q = '{subject:"Correction Checked & Done" subject:"Correction Not Done" subject:"Correction Update"}';
  const sent = await fetchList('in:sent {subject:"Correction Not Done - Ticket" subject:"Correction Update - Ticket"}', "sent", 40);
  const replies = await fetchList(`-in:sent -in:chats ${q}`, "reply", 40);
  const all = [...sent, ...replies].filter((m) => /Correction (Checked & Done|Not Done|Update) - Ticket/i.test(m.subject));
  all.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  mailCache = { mails: all, at: Date.now() };
  return { mails: all };
}

export const listCorrectionMails = createServerFn({ method: "GET" }).handler(async () => {
  if (mailCache && Date.now() - mailCache.at < 30000) return { mails: mailCache.mails };
  if (!pendingMails) pendingMails = readCorrectionMails().finally(() => { pendingMails = null; });
  return pendingMails;
});

type MailPart = {
  mimeType?: string;
  filename?: string;
  body?: { data?: string };
  parts?: MailPart[];
};

function decodeBody(value: string) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  return new TextDecoder().decode(Uint8Array.from(atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=")), (char) => char.charCodeAt(0)));
}

export const getCorrectionMail = createServerFn({ method: "GET" })
  .inputValidator((data: { id: string }) => {
    if (!data || typeof data.id !== "string" || !/^[a-f0-9]{1,64}$/i.test(data.id)) throw new Error("Invalid message ID");
    return { id: data.id };
  })
  .handler(async ({ data }) => {
    const message = await gmail(`/users/me/messages/${data.id}?format=full`);
    if (!/Correction (Checked & Done|Not Done|Update)/i.test(header(message, "Subject"))) throw new Error("Not a correction message");
    const plain: string[] = [];
    const html: string[] = [];
    const attachments: string[] = [];
    function visit(part: MailPart) {
      if (part.filename) attachments.push(part.filename);
      else if (part.body?.data) {
        if (part.mimeType === "text/html") html.push(decodeBody(part.body.data));
        if (part.mimeType === "text/plain") plain.push(decodeBody(part.body.data));
      }
      part.parts?.forEach(visit);
    }
    visit(message.payload ?? {});
    return {
      id: message.id as string,
      from: header(message, "From"), to: header(message, "To"), cc: header(message, "Cc"),
      subject: header(message, "Subject"), date: header(message, "Date"),
      plain: plain.join("\n\n"), html: html.join("\n"), attachments,
    };
  });

const CORRECTION_SUBJECT = /Correction (Checked & Done|Not Done|Update) - Ticket/i;

function b64Utf8(s: string) {
  return btoa(Array.from(new TextEncoder().encode(s), (b) => String.fromCharCode(b)).join(""));
}
function mimeHeader(v: string) {
  return /^[\x00-\x7F]*$/.test(v) ? v : `=?UTF-8?B?${b64Utf8(v)}?=`;
}
function escHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function cleanList(v: string) {
  return v.split(/[,;]+/).map((s) => s.trim()).filter((s) => s.includes("@")).join(", ");
}

export const replyToCorrectionMail = createServerFn({ method: "POST" })
  .inputValidator((d: { id: string; to: string; cc?: string; body: string }) => {
    if (!d || !/^[a-f0-9]{1,64}$/i.test(d.id)) throw new Error("Invalid message ID");
    if (typeof d.body !== "string" || !d.body.trim()) throw new Error("Reply text is empty");
    if (d.body.length > 20000) throw new Error("Reply is too long");
    const to = cleanList(String(d.to || ""));
    if (!to) throw new Error("Add a valid recipient email");
    return { id: d.id, to, cc: cleanList(String(d.cc || "")), body: d.body };
  })
  .handler(async ({ data }) => {
    const orig = await gmail(`/users/me/messages/${data.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=Message-ID&metadataHeaders=References`);
    const subject0 = header(orig, "Subject");
    if (!CORRECTION_SUBJECT.test(subject0)) throw new Error("Not a correction message");
    const subject = /^re:/i.test(subject0) ? subject0 : `Re: ${subject0}`;
    const msgId = header(orig, "Message-ID");
    const refs = [header(orig, "References"), msgId].filter(Boolean).join(" ");
    const html = `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.55">${escHtml(data.body).replace(/\n/g, "<br>")}</div>`;
    const lines = [`To: ${data.to}`];
    if (data.cc) lines.push(`Cc: ${data.cc}`);
    lines.push(`Subject: ${mimeHeader(subject)}`);
    if (msgId) lines.push(`In-Reply-To: ${msgId}`, `References: ${refs}`);
    lines.push("MIME-Version: 1.0", 'Content-Type: text/html; charset="UTF-8"', "", html);
    const raw = b64Utf8(lines.join("\r\n")).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const res = await fetch(`${GMAIL}/users/me/messages/send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.LOVABLE_API_KEY}`, "X-Connection-Api-Key": `${process.env.GOOGLE_MAIL_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ raw, threadId: orig.threadId }),
    });
    if (!res.ok) throw new Error(`Gmail [${res.status}]: ${await res.text()}`);
    mailCache = null;
    return { ok: true };
  });
