import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getCorrectionValues } from "@/lib/corrections.functions";

const REFRESH_MS = 60_000;
let cachedRows: Row[] | null = null;
let cachedAt: Date | null = null;
let pendingLoad: Promise<Row[]> | null = null;

export type Row = {
  timestamp: string;
  email: string;
  ticket: string;
  correctedDate: string;
  field: string;
  incorrect: string;
  correct: string;
  reason: string;
  zone: string;
  tl: string;
  checked: boolean;
  checkedStatus: string;
  remark: string;
  revertSent: string;
  dateKey: string;
  correctedKey: string;
  sameDay: boolean;
  dayDiff: number; // timestamp - correctedDate in days (positive = updated later)
};

export function parseDateFlexible(s: string): string {
  if (!s) return "";
  const str = s.trim();
  const datePart = str.split(" ")[0];
  if (datePart.includes("/")) {
    const parts = datePart.split("/");
    if (parts.length === 3) {
      // Sheet dates are DD/MM/YYYY (Indian format)
      const [d, m, y] = parts;
      const yyyy = y.length === 2 ? `20${y}` : y;
      return `${yyyy}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
    }
  }
  if (/^\d{4}-\d{2}-\d{2}/.test(datePart)) return datePart.slice(0, 10);
  const dt = new Date(str);
  if (!isNaN(dt.getTime())) {
    return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
  }
  return "";
}

function pick(r: Record<string, string>, keys: string[]): string {
  for (const k of keys) {
    if (r[k] != null && r[k] !== "") return r[k];
  }
  return "";
}

function mapValues(values: string[][]): Row[] {
  if (values.length === 0) return [];
  const headers = values[0].map((header) => (header || "").trim());
  return values.slice(1).map((cells) => {
    const record = Object.fromEntries(headers.map((header, index) => [header, cells[index] ?? ""]));
    const ts = pick(record, ["Timestamp"]).trim();
    const cd = pick(record, ["Ticket Corrected Date"]).trim();
    const dateKey = parseDateFlexible(ts);
    const correctedKey = parseDateFlexible(cd);
    let dayDiff = 0;
    if (dateKey && correctedKey) {
      const submitted = new Date(dateKey + "T00:00:00");
      const corrected = new Date(correctedKey + "T00:00:00");
      dayDiff = Math.round((submitted.getTime() - corrected.getTime()) / 86400000);
    }
    const checkedStatus = pick(record, ["Checked Status"]).trim();
    return {
      timestamp: ts,
      email: pick(record, ["Email Address"]).trim().toLowerCase(),
      ticket: pick(record, ["Ticket Details"]).trim(),
      correctedDate: cd,
      field: pick(record, ["Select Field to be Corrected"]).trim(),
      incorrect: pick(record, ["Incorrect Value Entered"]).trim(),
      correct: pick(record, ["Correct Value to be Updated"]).trim(),
      reason: pick(record, ["Reason for Correction"]).trim(),
      zone: pick(record, ["Zone"]).trim(),
      tl: pick(record, ["TL Name", "Under TL Name"]).trim(),
      checkedStatus,
      remark: pick(record, ["Remark"]).trim(),
      revertSent: pick(record, ["Revert Sent"]).trim(),
      checked: checkedStatus.toLowerCase().startsWith("done"),
      dateKey,
      correctedKey,
      sameDay: !!dateKey && !!correctedKey && dateKey === correctedKey,
      dayDiff,
    };
  }).filter((row) => row.timestamp);
}

export function useCorrections() {
  const fetchCorrectionValues = useServerFn(getCorrectionValues);
  const [rows, setRows] = useState<Row[]>(() => cachedRows ?? []);
  const [loading, setLoading] = useState(cachedRows === null);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(() => cachedAt);

  const load = async (showLoading = false) => {
    try {
      if (showLoading || cachedRows === null) setLoading(true);
      if (!pendingLoad) pendingLoad = fetchCorrectionValues()
        .then(({ values }) => mapValues(values))
        .finally(() => { pendingLoad = null; });
      const mapped = await pendingLoad;
      cachedRows = mapped;
      cachedAt = new Date();
      setRows(mapped);
      setLastUpdated(cachedAt);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to reload corrections");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (cachedRows === null) load(true);
    const id = setInterval(() => load(false), REFRESH_MS);
    return () => clearInterval(id);
  }, [fetchCorrectionValues]);

  return { rows, loading, error, lastUpdated, reload: () => load(true) };
}

export function toKey(d: Date | undefined): string {
  if (!d) return "";
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
