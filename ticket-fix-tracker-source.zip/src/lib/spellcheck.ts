// Lightweight spelling helper for the remark box: catches the most common
// typos we see in correction remarks and offers a one-click fix.
const FIXES: Record<string, string> = {
  teh: "the",
  adn: "and",
  recieve: "receive",
  recieved: "received",
  seperate: "separate",
  seperated: "separate",
  occured: "occurred",
  occuring: "occurring",
  definately: "definitely",
  accomodate: "accommodate",
  begining: "beginning",
  beleive: "believe",
  calender: "calendar",
  comming: "coming",
  commited: "committed",
  completly: "completely",
  correcly: "correctly",
  corection: "correction",
  corrction: "correction",
  correciton: "correction",
  currect: "correct",
  detials: "details",
  dificult: "difficult",
  enviroment: "environment",
  everytime: "every time",
  excercise: "exercise",
  experiance: "experience",
  finaly: "finally",
  folowing: "following",
  foward: "forward",
  futhermore: "furthermore",
  happend: "happened",
  imediately: "immediately",
  immediatly: "immediately",
  inforamtion: "information",
  informations: "information",
  interupt: "interrupt",
  kindly_do: "kindly do",
  maintainance: "maintenance",
  managment: "management",
  mentiond: "mentioned",
  mistke: "mistake",
  neccessary: "necessary",
  necesary: "necessary",
  noticable: "noticeable",
  occassion: "occasion",
  paymnet: "payment",
  perfomance: "performance",
  plese: "please",
  pls: "please",
  posible: "possible",
  practise: "practice",
  probelm: "problem",
  proccess: "process",
  quantitiy: "quantity",
  quering: "querying",
  recomend: "recommend",
  refered: "referred",
  remak: "remark",
  remarkes: "remarks",
  repsonse: "response",
  requirment: "requirement",
  resturant: "restaurant",
  restarunt: "restaurant",
  reverted_back: "reverted",
  sucess: "success",
  succesful: "successful",
  successfull: "successful",
  supose: "suppose",
  teh_same: "the same",
  ther: "there",
  therefor: "therefore",
  thier: "their",
  tommorow: "tomorrow",
  tommorrow: "tomorrow",
  trainner: "trainer",
  trianer: "trainer",
  truely: "truly",
  updted: "updated",
  upadte: "update",
  usuallly: "usually",
  varification: "verification",
  verfied: "verified",
  wich: "which",
  writen: "written",
  wrongly_entered: "wrongly entered",
  yoru: "your",
  youre: "you're",
};

export type SpellIssue = { word: string; suggestion: string };

export function findSpellingIssues(text: string): SpellIssue[] {
  const seen = new Set<string>();
  const issues: SpellIssue[] = [];
  for (const raw of text.split(/[^A-Za-z']+/)) {
    const w = raw.toLowerCase();
    if (!w || seen.has(w)) continue;
    const fix = FIXES[w];
    if (fix) {
      seen.add(w);
      issues.push({ word: raw, suggestion: fix });
    }
  }
  return issues;
}

export function applyFix(text: string, word: string, suggestion: string): string {
  const re = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
  return text.replace(re, (m) =>
    m[0] === m[0].toUpperCase() ? suggestion[0].toUpperCase() + suggestion.slice(1) : suggestion,
  );
}

export function fixAll(text: string): string {
  let out = text;
  for (const i of findSpellingIssues(text)) out = applyFix(out, i.word, i.suggestion);
  return out;
}
