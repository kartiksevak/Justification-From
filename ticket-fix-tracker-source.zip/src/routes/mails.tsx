import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { ArrowLeft, CheckCircle2, ChevronLeft, ChevronRight, Inbox, Mail, Paperclip, Search, Send } from "lucide-react";
import { readMarkDoneLog } from "@/lib/markDoneLog";
import { DashboardShell } from "@/components/DashboardShell";
import { Button } from "@/components/ui/button";
import { getCorrectionMail, listCorrectionMails, replyToCorrectionMail, type MailItem } from "@/lib/mails.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/mails")({
  head: () => ({
    meta: [
      { title: "Email Activity — Corrections Dashboard" },
      {
        name: "description",
        content: "All revert emails sent from the dashboard and trainer replies with ticket, trainer, date and status.",
      },
      { property: "og:title", content: "Email Activity — Corrections Dashboard" },
      { property: "og:description", content: "Sent reverts and trainer replies by ticket, trainer, date and status." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MailsPage,
});

function fmtDate(d: string) {
  const t = new Date(d);
  return Number.isNaN(t.getTime()) ? d : t.toLocaleString();
}

function parseMail(m: MailItem) {
  const ticket = m.subject.match(/Ticket\s*#?\s*(\S+)/i)?.[1] ?? "—";
  const status = /Not Done/i.test(m.subject) ? "Not Done" : /Checked & Done|Correction Update/i.test(m.subject) ? "Done" : "—";
  const who = m.direction === "sent" ? m.to : m.from;
  const email = who.match(/<([^>]+)>/)?.[1] ?? who.split(",")[0].trim();
  const trainer = email.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  return { ticket, status, trainer, email };
}

function MailsPage() {
  const [filter, setFilter] = useState<"all" | "sent" | "reply" | "done">("all");
  const [doneEntries] = useState(() => readMarkDoneLog());
  const [status, setStatus] = useState<"all" | "Done" | "Not Done">("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const fetchMails = useServerFn(listCorrectionMails);
  const fetchMail = useServerFn(getCorrectionMail);
  const { data, dataUpdatedAt, isFetching, refetch, error } = useQuery({
    queryKey: ["correction-mails"], queryFn: () => fetchMails(), refetchInterval: 120000,
  });
  const detail = useQuery({
    queryKey: ["correction-mail", selected],
    queryFn: () => {
      if (!selected) throw new Error("Choose a message");
      return fetchMail({ data: { id: selected } });
    },
    enabled: selected !== null, staleTime: 300000,
  });
  const mails = (data?.mails ?? []).map((m) => ({ ...m, ...parseMail(m) }));
  const q = search.trim().toLowerCase();
  const rows = mails.filter((m) =>
    (filter === "all" || filter === "done" || m.direction === filter) && (status === "all" || m.status === status) &&
    (!q || `${m.ticket} ${m.trainer} ${m.email} ${m.subject} ${m.cc} ${m.snippet}`.toLowerCase().includes(q)),
  );
  const selectedIndex = rows.findIndex((m) => m.id === selected);
  const active = rows[selectedIndex];
  const sentCount = mails.filter((m) => m.direction === "sent").length;
  const message = detail.data;
  const changeFilter = (value: typeof filter) => { setFilter(value); setSelected(null); };

  return (
    <DashboardShell lastUpdated={dataUpdatedAt ? new Date(dataUpdatedAt) : null} loading={isFetching} onReload={() => refetch()}>
      <section className="min-w-0 text-foreground">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h1 className="flex items-center gap-2 text-xl font-semibold"><Mail className="size-5" /> Email Activity</h1>
          <p className="text-sm text-muted-foreground">{mails.length} messages · {sentCount} sent · {mails.length - sentCount} replies</p>
        </div>
        <div className="grid min-w-0 gap-4 md:grid-cols-[180px_minmax(0,1fr)]">
          <nav aria-label="Mail folders" className="flex gap-1 overflow-x-auto md:flex-col">
            {([
              ["all", "All mail", Inbox, mails.length],
              ["sent", "Sent by us", Send, sentCount],
              ["reply", "Trainer replies", Mail, mails.length - sentCount],
              ["done", "Mark Done", CheckCircle2, doneEntries.length],
            ] as const).map(([key, label, Icon, count]) => (
              <Button key={key} variant={filter === key ? "secondary" : "ghost"} onClick={() => changeFilter(key)} className="justify-start" aria-pressed={filter === key}>
                <Icon /><span>{label}</span><span className="ml-auto text-xs text-muted-foreground">{count}</span>
              </Button>
            ))}
          </nav>
          <div className="min-w-0 border border-border bg-card">
            {selected ? (
              <>
                <div className="flex items-center gap-2 border-b border-border p-2">
                  <Button variant="ghost" size="icon" onClick={() => setSelected(null)} aria-label="Back to mail list" title="Back to mail list"><ArrowLeft /></Button>
                  <span className="ml-auto text-xs text-muted-foreground">{selectedIndex >= 0 ? `${selectedIndex + 1} of ${rows.length}` : "Message"}</span>
                  <Button variant="ghost" size="icon" disabled={selectedIndex <= 0} onClick={() => setSelected(rows[selectedIndex - 1]?.id ?? null)} aria-label="Previous message" title="Previous message"><ChevronLeft /></Button>
                  <Button variant="ghost" size="icon" disabled={selectedIndex < 0 || selectedIndex >= rows.length - 1} onClick={() => setSelected(rows[selectedIndex + 1]?.id ?? null)} aria-label="Next message" title="Next message"><ChevronRight /></Button>
                </div>
                <article className="min-w-0 p-4 sm:p-6" aria-label="Opened email">
                  <h2 className="mb-4 break-words text-xl font-semibold">{message?.subject ?? active?.subject}</h2>
                  <div className="mb-5 space-y-1 break-words border-b border-border pb-4 text-sm">
                    <p><span className="text-muted-foreground">From: </span>{message?.from ?? active?.from}</p>
                    <p><span className="text-muted-foreground">To: </span>{message?.to ?? active?.to}</p>
                    {(message?.cc || active?.cc) && <p><span className="text-muted-foreground">Cc: </span>{message?.cc ?? active?.cc}</p>}
                    <p className="text-xs text-muted-foreground">{fmtDate(message?.date ?? active?.date ?? "")}</p>
                    {active && <p className="text-xs text-muted-foreground">Ticket {active.ticket} · {active.trainer} · {active.status} · {active.direction === "sent" ? "Sent" : "Reply"}</p>}
                  </div>
                  {detail.isPending && <p role="status" className="py-8 text-muted-foreground">Loading full message…</p>}
                  {detail.error && <div role="alert" className="space-y-3 text-sm text-destructive"><p>Could not open this message: {detail.error.message}</p><Button variant="outline" onClick={() => detail.refetch()}>Try again</Button></div>}
                  {message && (message.html ? (
                    <iframe
                      title="Full email message"
                      sandbox=""
                      referrerPolicy="no-referrer"
                      className="h-[650px] w-full border-0 bg-card"
                      srcDoc={`<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data: cid:; font-src 'none'; form-action 'none'; base-uri 'none'"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>${message.html}</body></html>`}
                    />
                  ) : <div className="whitespace-pre-wrap break-words text-sm leading-7">{message.plain || "This message has no text body."}</div>)}
                  {!!message?.attachments.length && <div className="mt-4 flex flex-wrap gap-3 border-t border-border pt-4">{message.attachments.map((name, index) => <span key={`${name}-${index}`} className="flex items-center gap-2 break-all text-sm text-muted-foreground"><Paperclip className="size-4 shrink-0" />{name}</span>)}</div>}
                </article>
                {active && <ReplyBox key={active.id} id={active.id} defaultTo={active.email} defaultCc={active.cc} onSent={() => refetch()} />}
              </>
            ) : (
              <>
                <div className="flex flex-wrap items-center gap-2 border-b border-border p-3">
                  <label className="flex min-w-0 flex-1 items-center gap-2 bg-muted px-3 py-2">
                    <Search className="size-4 shrink-0 text-muted-foreground" />
                    <input aria-label="Search emails" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search ticket, trainer, subject…" className="min-w-0 w-full bg-transparent text-sm outline-none" />
                  </label>
                  <select aria-label="Filter mail status" value={status} onChange={(e) => setStatus(e.target.value as typeof status)} className="border border-input bg-background px-3 py-2 text-sm">
                    <option value="all">All status</option><option value="Done">Done</option><option value="Not Done">Not Done</option>
                  </select>
                </div>
                {filter === "done" ? (
                  <div className="divide-y divide-border">
                    {doneEntries.filter((e) => !q || `${e.ticket} ${e.email} ${e.field}`.toLowerCase().includes(q)).map((e, i) => (
                      <div key={`${e.ticket}-${e.at}-${i}`} className="flex items-center gap-3 px-4 py-3">
                        <CheckCircle2 className="size-4 shrink-0 text-primary" />
                        <span className="grid min-w-0 flex-1 gap-1 lg:grid-cols-[150px_minmax(0,1fr)_110px] lg:gap-4">
                          <span className="truncate font-semibold">Ticket {e.ticket}<span className="block text-xs font-normal text-muted-foreground">Mark Done</span></span>
                          <span className="min-w-0"><span className="block truncate text-sm">{e.email}</span><span className="block truncate text-xs text-muted-foreground">{e.field}</span></span>
                          <span className="text-xs text-muted-foreground lg:text-right">{fmtDate(e.at)}</span>
                        </span>
                      </div>
                    ))}
                    {doneEntries.length === 0 && <p role="status" className="p-10 text-center text-sm text-muted-foreground">Abhi tak koi Mark Done entry nahi hai.</p>}
                  </div>
                ) : (
                <>
                {error && <p role="alert" className="p-4 text-sm text-destructive">{error.message}</p>}
                {!error && rows.length === 0 && <p role="status" className="p-10 text-center text-sm text-muted-foreground">{isFetching ? "Loading mails…" : "No mails found."}</p>}
                <div className="divide-y divide-border">
                  {rows.map((m) => (
                    <Button key={m.id} variant="ghost" onClick={() => setSelected(m.id)} aria-label={`Open email: ${m.subject}`} className="h-auto w-full justify-start whitespace-normal rounded-none px-4 py-3 text-left">
                      {m.direction === "sent" ? <Send className="text-muted-foreground" /> : <Mail className="text-primary" />}
                      <span className="grid min-w-0 flex-1 gap-1 lg:grid-cols-[150px_minmax(0,1fr)_110px] lg:gap-4">
                        <span className="truncate font-semibold">{m.trainer}<span className="block text-xs font-normal text-muted-foreground">{m.direction === "sent" ? "Sent" : "Reply"} · {m.status}</span></span>
                        <span className="min-w-0"><span className="block truncate font-semibold">{m.subject}</span><span className="block truncate text-xs font-normal text-muted-foreground">{m.snippet}</span></span>
                        <span className="text-xs font-normal text-muted-foreground lg:text-right">{fmtDate(m.date)}</span>
                      </span>
                    </Button>
                  ))}
                </div>
                </>
                )}
              </>
            )}
          </div>
        </div>
      </section>
    </DashboardShell>
  );
}

function ReplyBox({ id, defaultTo, defaultCc, onSent }: { id: string; defaultTo: string; defaultCc: string; onSent: () => void }) {
  const send = useServerFn(replyToCorrectionMail);
  const [to, setTo] = useState(defaultTo);
  const [cc, setCc] = useState(defaultCc);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const submit = async () => {
    setSending(true);
    try {
      await send({ data: { id, to, cc, body } });
      toast.success(`Reply sent to ${to}`);
      setBody("");
      onSent();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Reply failed");
    } finally { setSending(false); }
  };
  return (
    <div className="space-y-2 border-t border-border p-4 sm:p-6">
      <h3 className="font-semibold">Reply</h3>
      <label className="flex items-center gap-2 text-sm"><span className="w-8 text-muted-foreground">To</span><input aria-label="Reply to" value={to} onChange={(e) => setTo(e.target.value)} className="min-w-0 flex-1 border border-input bg-background px-3 py-2" /></label>
      <label className="flex items-center gap-2 text-sm"><span className="w-8 text-muted-foreground">Cc</span><input aria-label="Reply cc" value={cc} onChange={(e) => setCc(e.target.value)} placeholder="Add more emails, comma separated" className="min-w-0 flex-1 border border-input bg-background px-3 py-2" /></label>
      <textarea aria-label="Reply message" spellCheck lang="en" value={body} onChange={(e) => setBody(e.target.value)} rows={5} placeholder="Write your reply…" className="w-full border border-input bg-background px-3 py-2 text-sm" />
      <div className="flex justify-end"><Button onClick={submit} disabled={sending || !body.trim() || !to.includes("@")}><Send />{sending ? "Sending…" : "Send reply"}</Button></div>
    </div>
  );
}
