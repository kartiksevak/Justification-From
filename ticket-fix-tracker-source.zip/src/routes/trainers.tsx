import { createFileRoute } from "@tanstack/react-router";
import { Fragment, useMemo, useState } from "react";
import { useCorrections, toKey } from "@/lib/useCorrections";
import { DashboardShell, DateRangePicker, StatCard } from "@/components/DashboardShell";
import { Download } from "lucide-react";
import { downloadCsv } from "@/lib/exportCsv";

export const Route = createFileRoute("/trainers")({
  component: TrainersView,
  head: () => ({
    meta: [
      { title: "Trainer Counts · Trainer Corrections" },
      { name: "description", content: "How many correction forms each trainer has submitted so far, with full details." },
      { property: "og:title", content: "Trainer Counts · Trainer Corrections" },
      { property: "og:description", content: "Per-trainer correction form submission counts and details." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type TrainerStat = {
  email: string;
  total: number;
  tls: string[];
  zones: string[];
  sameDay: number;
  oneDay: number;
  other: number;
  firstDate: string;
  lastDate: string;
  fields: [string, number][];
  tickets: number;
};

function TrainersView() {
  const { rows, loading, error, lastUpdated, reload } = useCorrections();
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState<Date | undefined>();
  const [to, setTo] = useState<Date | undefined>();
  const [open, setOpen] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const PER = 15;

  const fromKey = toKey(from);
  const toK = toKey(to);

  const stats = useMemo<TrainerStat[]>(() => {
    const q = search.trim().toLowerCase();
    const map = new Map<string, TrainerStat & { _fields: Map<string, number>; _tickets: Set<string> }>();
    rows.forEach((r) => {
      if (!r.email) return;
      if (fromKey && r.dateKey < fromKey) return;
      if (toK && r.dateKey > toK) return;
      if (q && !(`${r.email} ${r.tl} ${r.zone}`.toLowerCase().includes(q))) return;
      let s = map.get(r.email);
      if (!s) {
        s = {
          email: r.email, total: 0, tls: [], zones: [], sameDay: 0, oneDay: 0, other: 0,
          firstDate: r.dateKey, lastDate: r.dateKey, fields: [], tickets: 0,
          _fields: new Map(), _tickets: new Set(),
        };
        map.set(r.email, s);
      }
      s.total += 1;
      if (r.tl && !s.tls.includes(r.tl)) s.tls.push(r.tl);
      if (r.zone && !s.zones.includes(r.zone)) s.zones.push(r.zone);
      if (r.sameDay) s.sameDay += 1;
      else if (r.dayDiff === 1) s.oneDay += 1;
      else s.other += 1;
      if (r.dateKey) {
        if (!s.firstDate || r.dateKey < s.firstDate) s.firstDate = r.dateKey;
        if (!s.lastDate || r.dateKey > s.lastDate) s.lastDate = r.dateKey;
      }
      if (r.field) s._fields.set(r.field, (s._fields.get(r.field) || 0) + 1);
      if (r.ticket) s._tickets.add(r.ticket);
    });
    return Array.from(map.values())
      .map((s) => ({
        ...s,
        tickets: s._tickets.size,
        fields: Array.from(s._fields.entries()).sort((a, b) => b[1] - a[1]),
      }))
      .sort((a, b) => b.total - a.total);
  }, [rows, search, fromKey, toK]);

  const pages = Math.max(1, Math.ceil(stats.length / PER));
  const current = Math.min(page, pages - 1);
  const view = stats.slice(current * PER, current * PER + PER);

  const download = () => {
    // Every field type becomes its own CSV column, sorted by overall usage.
    const fieldTotals = new Map<string, number>();
    stats.forEach((s) => s.fields.forEach(([f, c]) => fieldTotals.set(f, (fieldTotals.get(f) || 0) + c)));
    const allFields = Array.from(fieldTotals.entries()).sort((a, b) => b[1] - a[1]).map(([f]) => f);
    const perField = new Map(stats.map((s) => [s.email, new Map(s.fields)]));

    downloadCsv(
      "trainer-form-counts",
      [
        "Trainer Email", "Total Forms", "Same-Day", "1-Day Late", "Other Days",
        "First Submission", "Last Submission", "Under TL", "Zone",
        ...allFields,
      ],
      stats.map((s) => {
        const fields = perField.get(s.email)!;
        return [
          s.email, String(s.total), String(s.sameDay), String(s.oneDay), String(s.other),
          s.firstDate, s.lastDate, s.tls.join(" | "), s.zones.join(" | "),
          ...allFields.map((f) => String(fields.get(f) || 0)),
        ];
      }),
    );
  };

  const totalForms = stats.reduce((a, b) => a + b.total, 0);

  return (
    <DashboardShell lastUpdated={lastUpdated} loading={loading} onReload={reload}>
      {error && <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <input
          type="search"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          placeholder="🔍 Search trainer email, TL or zone…"
          className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        />
        <DateRangePicker from={from} to={to} onChange={(f, t) => { setFrom(f); setTo(t); setPage(0); }} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Trainers" value={stats.length} color="bg-indigo-600" />
        <StatCard label="Total Forms Filled" value={totalForms} color="bg-emerald-600" />
        <StatCard label="Avg Forms / Trainer" value={stats.length ? Math.round((totalForms / stats.length) * 10) / 10 : 0} color="bg-amber-600" />
        <StatCard label="Top Trainer Forms" value={stats[0]?.total ?? 0} color="bg-rose-600" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button onClick={download} className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-emerald-700">
          <Download className="h-4 w-4" /> Download trainer counts CSV
        </button>
        <span className="text-xs text-slate-500">({stats.length} trainers)</span>
      </div>

      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-left text-xs uppercase tracking-wide text-slate-600">
            <tr>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">Trainer</th>
              <th className="px-3 py-2">Forms</th>
              <th className="px-3 py-2">Same-Day</th>
              <th className="px-3 py-2">1-Day Late</th>
              <th className="px-3 py-2">Other</th>
              <th className="px-3 py-2">Last</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {view.map((s, i) => (
              <Fragment key={s.email}>
                <tr className="hover:bg-slate-50">
                  <td className="px-3 py-2 text-slate-500">{current * PER + i + 1}</td>
                  <td className="px-3 py-2 font-medium text-slate-900 max-w-[240px] truncate" title={s.email}>{s.email}</td>
                  <td className="px-3 py-2"><span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-700">{s.total}</span></td>
                  <td className="px-3 py-2 text-sky-700">{s.sameDay}</td>
                  <td className="px-3 py-2 text-amber-700">{s.oneDay}</td>
                  <td className="px-3 py-2 text-rose-700">{s.other}</td>
                  <td className="px-3 py-2 text-xs text-slate-500">{s.lastDate}</td>
                  <td className="px-3 py-2 text-right">
                    <button
                      onClick={() => setOpen(open === s.email ? null : s.email)}
                      className="rounded-md border border-slate-300 px-2 py-1 text-xs hover:bg-slate-100"
                    >
                      {open === s.email ? "Hide" : "Details"}
                    </button>
                  </td>
                </tr>
                {open === s.email && (
                  <tr className="bg-slate-50">
                    <td colSpan={8} className="px-3 py-3">
                      <div className="grid gap-2 md:grid-cols-3 text-xs text-slate-700">
                        <p><span className="font-semibold">Under TL:</span> {s.tls.join(", ") || "—"}</p>
                        <p><span className="font-semibold">Zone:</span> {s.zones.join(", ") || "—"}</p>
                        <p><span className="font-semibold">Active:</span> {s.firstDate} → {s.lastDate}</p>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {s.fields.map(([f, c]) => (
                          <span key={f} className="rounded-md bg-white border border-slate-200 px-2 py-0.5 text-xs">
                            {f} <span className="font-semibold text-indigo-700">{c}</span>
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
            {view.length === 0 && !loading && (
              <tr><td colSpan={8} className="px-3 py-6 text-center text-slate-500">No records</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {pages > 1 && (
        <div className="flex flex-wrap items-center gap-1">
          {Array.from({ length: pages }, (_, i) => i).map((p) => (
            <button
              key={p}
              onClick={() => setPage(p)}
              className={`rounded-md px-2.5 py-1 text-xs font-medium ${p === current ? "bg-indigo-600 text-white" : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-100"}`}
            >
              {p * PER + 1}–{Math.min((p + 1) * PER, stats.length)}
            </button>
          ))}
        </div>
      )}
    </DashboardShell>
  );
}
