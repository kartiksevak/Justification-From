import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useCorrections, toKey, type Row } from "@/lib/useCorrections";
import { DashboardShell, DateRangePicker, StatCard } from "@/components/DashboardShell";
import { updateCorrectionCell, saveRevertAndSend } from "@/lib/sheetEdit.functions";
import { logMarkDone } from "@/lib/markDoneLog";
import { exportRows } from "@/lib/exportCsv";
import { useCheckedLocal, rowKey } from "@/lib/useChecked";
import { findTlEmail } from "@/lib/tlEmails";
import { findSpellingIssues, applyFix, fixAll } from "@/lib/spellcheck";
import { toast } from "sonner";
import { Check, CheckCheck, Download, Mail, Pencil, X } from "lucide-react";

export const Route = createFileRoute("/day-comparison")({
  component: DayComparison,
  head: () => ({
    meta: [
      { title: "Same vs Different Day · Trainer Corrections" },
      { name: "description", content: "Compare corrections filed on the same day versus a different day." },
      { property: "og:title", content: "Same vs Different Day · Trainer Corrections" },
      { property: "og:description", content: "Compare corrections filed on the same day versus a different day." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function DayComparison() {
  const { rows, loading, error, lastUpdated, reload } = useCorrections();
  const [search, setSearch] = useState("");
  const [zoneFilter, setZoneFilter] = useState("all");
  const [incorrectFilter, setIncorrectFilter] = useState("all");
  const [fieldFilter, setFieldFilter] = useState("all");
  const [from, setFrom] = useState<Date | undefined>();
  const [to, setTo] = useState<Date | undefined>();
  const zones = useMemo(() => Array.from(new Set(rows.map((r) => r.zone).filter(Boolean))).sort(), [rows]);
  const incorrects = useMemo(() => Array.from(new Set(rows.map((r) => r.incorrect).filter(Boolean))).sort(), [rows]);
  const fields = useMemo(
    () => Array.from(new Set(rows.map((r) => r.field).filter(Boolean))).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" })),
    [rows],
  );
  const fromKey = toKey(from);
  const toK = toKey(to);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (zoneFilter !== "all" && r.zone !== zoneFilter) return false;
      if (incorrectFilter !== "all" && r.incorrect !== incorrectFilter) return false;
      if (fieldFilter !== "all" && r.field !== fieldFilter) return false;
      if (fromKey && r.dateKey < fromKey) return false;
      if (toK && r.dateKey > toK) return false;
      if (!q) return true;
      return r.ticket.toLowerCase().includes(q) || r.email.toLowerCase().includes(q) || r.field.toLowerCase().includes(q) || r.reason.toLowerCase().includes(q);
    });
  }, [rows, search, zoneFilter, incorrectFilter, fieldFilter, fromKey, toK]);

  const { isChecked, setChecked } = useCheckedLocal();
  const [saving, setSaving] = useState<string | null>(null);
  const [markErr, setMarkErr] = useState<string | null>(null);
  const [bulkBusy, setBulkBusy] = useState<string | null>(null);

  const bulkDone = async (selectedRows: Row[]) => {
    if (selectedRows.length === 0) return;
    setMarkErr(null);
    let failed = 0;
    for (let i = 0; i < selectedRows.length; i++) {
      const r = selectedRows[i];
      setBulkBusy(`Marking done ${i + 1}/${selectedRows.length}…`);
      setChecked(r, true);
      try {
        await updateCorrectionCell({
          data: {
            ticket: r.ticket,
            timestamp: r.timestamp,
            email: r.email,
            field: "Checked Status",
            remark: r.remark,
            value: `Done · ${new Date().toLocaleString()}`,
          },
        });
        logMarkDone({ ticket: r.ticket, email: r.email, field: r.field });
      } catch {
        setChecked(r, false);
        failed++;
      }
    }
    setBulkBusy(null);
    if (failed) setMarkErr(`${failed} of ${selectedRows.length} could not be marked done`);
    reload();
  };

  const toggleDone = async (r: Row, value: boolean) => {
    setSaving(rowKey(r));
    setMarkErr(null);
    setChecked(r, value);
    try {
      await updateCorrectionCell({
        data: {
          ticket: r.ticket,
          timestamp: r.timestamp,
          email: r.email,
          field: "Checked Status",
          remark: r.remark,
          value: value ? `Done · ${new Date().toLocaleString()}` : "",
        },
      });
      if (value) logMarkDone({ ticket: r.ticket, email: r.email, field: r.field });
      reload();
    } catch (e) {
      setChecked(r, !value);
      setMarkErr(e instanceof Error ? e.message : "Failed to mark done");
    } finally {
      setSaving(null);
    }
  };

  const pending = filtered.filter((r) => !isChecked(r));
  const doneRows = filtered.filter((r) => isChecked(r));
  const sameDayRows = pending.filter((r) => r.sameDay);
  const oneDayLateRows = pending.filter((r) => r.dayDiff === 1);
  const diffDayRows = pending.filter((r) => !r.sameDay && r.dayDiff !== 1);
  const [editing, setEditing] = useState<Row | null>(null);
  const [reverting, setReverting] = useState<Row | null>(null);
  const [viewFilter, setViewFilter] = useState("all");

  const show = (key: string) =>
    viewFilter === "all" || viewFilter === key ||
    (viewFilter === "pending" && ["same", "one", "diff"].includes(key));
  const showPending = true;

  return (
    <DashboardShell lastUpdated={lastUpdated} loading={loading} onReload={reload}>
      {error && <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="🔍 Search Ticket ID, email, field, reason…"
          className="md:col-span-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        />
        <select value={zoneFilter} onChange={(e) => setZoneFilter(e.target.value)} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="all">All Zones</option>
          {zones.map((z) => <option key={z} value={z}>{z}</option>)}
        </select>
        <select value={incorrectFilter} onChange={(e) => setIncorrectFilter(e.target.value)} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="all">All Incorrect Values</option>
          {incorrects.map((v) => <option key={v} value={v}>{v}</option>)}
        </select>
        <select value={fieldFilter} onChange={(e) => setFieldFilter(e.target.value)} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="all">All Fields</option>
          {fields.map((f) => <option key={f} value={f}>{f.length > 48 ? `${f.slice(0, 48)}…` : f}</option>)}
        </select>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <DateRangePicker from={from} to={to} onChange={(f, t) => { setFrom(f); setTo(t); }} />
        <select value={viewFilter} onChange={(e) => setViewFilter(e.target.value)} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium">
          <option value="all">🔎 Show All ({filtered.length})</option>
          <option value="same">Same-Day ({sameDayRows.length})</option>
          <option value="one">1-Day Late ({oneDayLateRows.length})</option>
          <option value="diff">Different-Day ({diffDayRows.length})</option>
          <option value="pending">Pending ({pending.length})</option>
          <option value="done">Checked &amp; Done ({doneRows.length})</option>
        </select>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => exportRows(filtered, "corrections_all_filtered")} className="inline-flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white hover:bg-indigo-700">
          <Download className="h-4 w-4" /> Download all ({filtered.length})
        </button>
        <button onClick={() => exportRows(sameDayRows, "corrections_same_day")} className="inline-flex items-center gap-1.5 rounded-md border border-sky-300 bg-white px-3 py-2 text-sm font-medium text-sky-700 hover:bg-sky-50">
          <Download className="h-4 w-4" /> Same-Day ({sameDayRows.length})
        </button>
        <button onClick={() => exportRows(oneDayLateRows, "corrections_1_day_late")} className="inline-flex items-center gap-1.5 rounded-md border border-amber-300 bg-white px-3 py-2 text-sm font-medium text-amber-700 hover:bg-amber-50">
          <Download className="h-4 w-4" /> 1-Day Late ({oneDayLateRows.length})
        </button>
        <button onClick={() => exportRows(diffDayRows, "corrections_different_day")} className="inline-flex items-center gap-1.5 rounded-md border border-rose-300 bg-white px-3 py-2 text-sm font-medium text-rose-700 hover:bg-rose-50">
          <Download className="h-4 w-4" /> Different-Day ({diffDayRows.length})
        </button>
      </div>

      {markErr && <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">{markErr}</div>}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Same-Day (pending)" value={sameDayRows.length} color="bg-sky-600" />
        <StatCard label="1-Day Late (pending)" value={oneDayLateRows.length} color="bg-amber-600" />
        <StatCard label="Different-Day (pending)" value={diffDayRows.length} color="bg-rose-600" />
        <StatCard label="Checked & Done ✅" value={doneRows.length} color="bg-emerald-600" />
      </div>

      {show("same") && showPending && <PaginatedTable title={`Same-Day Corrections (${sameDayRows.length})`} subtitle="Timestamp date matches the Ticket Corrected Date" rows={sameDayRows} accent="border-l-4 border-sky-500" onEdit={setEditing} onRevert={setReverting} onDownload={() => exportRows(sameDayRows, "corrections_same_day")} isChecked={isChecked} onToggleDone={toggleDone} savingKey={saving} onBulkDone={bulkDone} bulkBusy={bulkBusy} />}
      {show("one") && showPending && <PaginatedTable title={`1-Day Late Corrections (${oneDayLateRows.length})`} subtitle="Ticket corrected exactly 1 day later (e.g. 5 ka ticket 6 ko update)" rows={oneDayLateRows} accent="border-l-4 border-amber-500" onEdit={setEditing} onRevert={setReverting} onDownload={() => exportRows(oneDayLateRows, "corrections_1_day_late")} isChecked={isChecked} onToggleDone={toggleDone} savingKey={saving} onBulkDone={bulkDone} bulkBusy={bulkBusy} />}
      {show("diff") && showPending && <PaginatedTable title={`Different-Day Corrections (${diffDayRows.length})`} subtitle="Timestamp date differs from Corrected Date (excluding 1-day late)" rows={diffDayRows} accent="border-l-4 border-rose-500" onEdit={setEditing} onRevert={setReverting} onDownload={() => exportRows(diffDayRows, "corrections_different_day")} isChecked={isChecked} onToggleDone={toggleDone} savingKey={saving} onBulkDone={bulkDone} bulkBusy={bulkBusy} />}
      {show("done") && <PaginatedTable title={`Checked & Done (${doneRows.length})`} subtitle="Aap ne check karke done mark kiya — sheet ki 'Checked Status' column me bhi save hai" rows={doneRows} accent="border-l-4 border-emerald-500" onEdit={setEditing} onRevert={setReverting} onDownload={() => exportRows(doneRows, "corrections_done")} isChecked={isChecked} onToggleDone={toggleDone} savingKey={saving} showCategory />}

      {editing && <EditModal row={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} />}
      {reverting && <RevertModal row={reverting} onClose={() => setReverting(null)} onSaved={(done) => { setChecked(reverting, done); setReverting(null); }} onFinished={reload} />}
    </DashboardShell>
  );
}

const EDITABLE_FIELDS = [
  "Ticket Details",
  "Ticket Corrected Date",
  "Select Field to be Corrected",
  "Incorrect Value Entered",
  "Correct Value to be Updated",
  "Reason for Correction",
  "Zone",
  "Under TL Name",
];

function EditModal({ row, onClose, onSaved }: { row: Row; onClose: () => void; onSaved: () => void }) {
  const initialValues: Record<string, string> = {
    "Ticket Details": row.ticket,
    "Ticket Corrected Date": row.correctedDate,
    "Select Field to be Corrected": row.field,
    "Incorrect Value Entered": row.incorrect,
    "Correct Value to be Updated": row.correct,
    "Reason for Correction": row.reason,
    "Zone": row.zone,
    "Under TL Name": row.tl,
  };
  const [values, setValues] = useState<Record<string, string>>(initialValues);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [progress, setProgress] = useState<string>("");

  const save = async () => {
    setSaving(true); setErr(null);
    try {
      const changed = EDITABLE_FIELDS.filter((f) => values[f] !== initialValues[f]);
      if (changed.length === 0) { setErr("No changes to save"); setSaving(false); return; }
      const changeList = changed.map((f) => ({ field: f, previousValue: initialValues[f], newValue: values[f] }));
      for (let i = 0; i < changed.length; i++) {
        const f = changed[i];
        const last = i === changed.length - 1;
        setProgress(`Saving ${i + 1}/${changed.length}: ${f}`);
        await updateCorrectionCell({ data: { ticket: row.ticket, timestamp: row.timestamp, email: row.email, field: f, value: values[f], notify: last, changes: last ? changeList : undefined } });
      }

      onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to update");
    } finally {
      setSaving(false); setProgress("");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-lg bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Edit correction — all fields</h3>
            <p className="text-xs text-slate-500">Ticket {row.ticket} · {row.email} · {row.timestamp}</p>
          </div>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-slate-100"><X className="h-4 w-4" /></button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4">
          {EDITABLE_FIELDS.map((f) => {
            const isLong = f === "Reason for Correction";
            const dirty = values[f] !== initialValues[f];
            return (
              <div key={f} className={isLong ? "md:col-span-2" : ""}>
                <label className="mb-1 block text-xs font-medium text-slate-600">
                  {f} {dirty && <span className="text-amber-600">• edited</span>}
                </label>
                {isLong ? (
                  <textarea value={values[f]} onChange={(e) => setValues({ ...values, [f]: e.target.value })} rows={2} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm" />
                ) : (
                  <input value={values[f]} onChange={(e) => setValues({ ...values, [f]: e.target.value })} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm" />
                )}
              </div>
            );
          })}
        </div>
        {(err || progress) && (
          <div className="px-4">
            {progress && <div className="rounded-md border border-slate-200 bg-slate-50 p-2 text-xs text-slate-700">{progress}</div>}
            {err && <div className="mt-2 rounded-md border border-red-200 bg-red-50 p-2 text-xs text-red-700">{err}</div>}
          </div>
        )}
        <div className="sticky bottom-0 flex justify-end gap-2 border-t border-slate-200 bg-white px-4 py-3">
          <button onClick={onClose} className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm">Cancel</button>
          <button onClick={save} disabled={saving} className="rounded-md bg-indigo-600 px-3 py-1.5 text-sm text-white hover:bg-indigo-700 disabled:opacity-50">
            {saving ? "Saving…" : "Save all changes"}
          </button>
        </div>
      </div>
    </div>
  );
}


function RevertModal({ row, onClose, onSaved, onFinished }: { row: Row; onClose: () => void; onSaved: (done: boolean) => void; onFinished: () => void }) {
  const [status, setStatus] = useState<"done" | "not">(row.checked ? "done" : "done");
  const [remark, setRemark] = useState(row.remark || "");
  const [cc, setCc] = useState(() => findTlEmail(row.tl));
  const [saving, setSaving] = useState(false);
  const [progress, setProgress] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const spellIssues = useMemo(() => findSpellingIssues(remark), [remark]);

  const subject = `Correction ${status === "done" ? "Checked & Done" : "Not Done"} - Ticket ${row.ticket}`;
  const body = [
    `Dear Trainer,`,
    ``,
    `The review of your correction form has been completed. Please find the details below.`,
    ``,
    `Ticket ID: ${row.ticket}`,
    `Form Submitted On: ${row.timestamp}`,
    `Ticket Corrected Date: ${row.correctedDate}`,
    `Field Corrected: ${row.field}`,
    `Incorrect Value Entered: ${row.incorrect}`,
    `Correct Value Updated: ${row.correct}`,
    `Reason for Correction: ${row.reason || "-"}`,
    `Zone: ${row.zone || "-"}   |   Under TL: ${row.tl || "-"}`,
    `Correction Category: ${categoryOf(row).label}`,
    ``,
    `Review Status: ${status === "done" ? "DONE / CHECKED" : "NOT DONE"}`,
    `Reviewer Remark: ${remark || "-"}`,
    ``,
    `If you have any questions regarding this review, please reply to this email.`,
    ``,
    `Thanks & Regards,`,
    `Kartik Sevak`,
    `Quality Check`,
  ].join("\n");

  const copyText = async () => {
    try {
      await navigator.clipboard.writeText(`To: ${row.email}${cc ? `\nCc: ${cc}` : ""}\nSubject: ${subject}\n\n${body}`);
      setProgress("Email text copied to clipboard");
      setTimeout(() => setProgress(""), 2000);
    } catch {
      setErr("Could not copy. Please select the preview text manually.");
    }
  };

  const saveAndSend = () => {
    setSaving(true); setErr(null);
    const stamp = new Date().toLocaleString();
    const statusValue = status === "done" ? `Done · ${stamp}` : `Not Done · ${stamp}`;
    const revertValue = `${status === "done" ? "Done" : "Not Done"} · ${stamp}`;

    // Fire in the background so the dashboard stays usable while Gmail + Sheets finish.
    const task = saveRevertAndSend({
      data: {
        ticket: row.ticket,
        timestamp: row.timestamp,
        email: row.email,
        fields: [
          { field: "Checked Status", value: statusValue },
          { field: "Remark", value: remark },
          { field: "Revert Sent", value: revertValue },
        ],
        mail: { to: row.email, cc, subject, body, remark },
        status,
        previousStatus: row.checkedStatus,
      },
    });

    toast.promise(task, {
      loading: `Sending revert for ticket ${row.ticket}…`,
      success: (result) => {
        if (result.emailSent && result.sheetSaved) return `Email sent to ${row.email}`;
        if (result.emailSent) return "Email sent, but sheet status could not be saved";
        if (result.sheetSaved) throw new Error(`Sheet saved, but email failed: ${result.mailError ?? "please retry"}`);
        throw new Error(result.mailError ?? result.sheetError ?? "Email and sheet update failed");
      },
      error: (e) => (e instanceof Error ? e.message : "Failed to send email"),
    });
    void task.finally(onFinished);

    onSaved(status === "done");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-lg bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Send revert to trainer</h3>
            <p className="text-xs text-slate-500">{row.email} · Ticket {row.ticket}</p>
          </div>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-slate-100"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-4 p-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-600">Status</label>
            <div className="flex gap-2">
              <button onClick={() => setStatus("done")} className={`rounded-md border px-3 py-1.5 text-sm font-medium ${status === "done" ? "border-emerald-500 bg-emerald-50 text-emerald-800" : "border-slate-300 bg-white text-slate-700"}`}>✅ Done / Checked</button>
              <button onClick={() => setStatus("not")} className={`rounded-md border px-3 py-1.5 text-sm font-medium ${status === "not" ? "border-rose-500 bg-rose-50 text-rose-800" : "border-slate-300 bg-white text-slate-700"}`}>❌ Not Done</button>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-600">Remark</label>
            <div className="relative min-h-[76px]">
              {remark && (
                <div aria-hidden className="pointer-events-none absolute inset-0 whitespace-pre-wrap break-words overflow-hidden rounded-md border border-transparent px-3 py-2 text-sm text-slate-800">
                  {remark.split(/(\b[A-Za-z']+\b)/).map((part, index) => {
                    const issue = spellIssues.find((item) => item.word.toLowerCase() === part.toLowerCase());
                    return issue ? (
                      <span key={`${part}-${index}`} className="underline decoration-red-600 decoration-wavy decoration-2 underline-offset-2">{part}</span>
                    ) : <span key={`${part}-${index}`}>{part}</span>;
                  })}
                </div>
              )}
              <textarea
                value={remark}
                onChange={(e) => setRemark(e.target.value)}
                rows={3}
                spellCheck
                lang="en-US"
                autoCorrect="on"
                autoCapitalize="sentences"
                placeholder="Write your remark…"
                className={`relative w-full resize-y rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm caret-slate-900 ${remark ? "text-transparent selection:bg-indigo-200" : "text-slate-900"}`}
              />
            </div>
            {spellIssues.length > 0 && (
              <div className="mt-2 rounded-md border border-red-200 bg-red-50 p-2 text-xs">
                <div className="mb-1 flex items-center justify-between gap-2">
                  <span className="font-medium text-red-700">Spelling check</span>
                  <button
                    onClick={() => setRemark(fixAll(remark))}
                    className="rounded border border-red-300 bg-white px-2 py-0.5 text-[11px] font-medium text-red-700 hover:bg-red-100"
                  >
                    Fix all
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {spellIssues.map((i) => (
                    <button
                      key={i.word}
                      onClick={() => setRemark(applyFix(remark, i.word, i.suggestion))}
                      className="rounded border border-red-300 bg-white px-2 py-0.5 text-[11px] text-slate-700 hover:bg-red-100"
                      title={`Replace with "${i.suggestion}"`}
                    >
                      <span className="text-red-600 underline decoration-red-500 decoration-wavy">{i.word}</span>
                      <span className="mx-1 text-slate-400">→</span>
                      <strong>{i.suggestion}</strong>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-600">CC (comma separated — they also receive this mail)</label>
            <input value={cc} onChange={(e) => setCc(e.target.value)} placeholder="tl@example.com, manager@example.com" className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm" />
          </div>
          <div>
            <p className="mb-1 text-xs font-medium text-slate-600">Email preview</p>
            <div className="max-h-40 overflow-y-auto whitespace-pre-wrap rounded-md border border-slate-200 bg-slate-50 p-2 text-[11px] text-slate-700">
              <div>To: {row.email}</div>
              {cc && <div>Cc: {cc}</div>}
              <div>Subject: {subject}</div>
              <br />
              {body.split("\n").map((line, index) => (
                <div key={`${index}-${line}`}>
                  {line.startsWith("Reviewer Remark: ") ? <><span>Reviewer Remark: </span><strong>{remark || "-"}</strong></> : line || <br />}
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={copyText} className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Copy email text</button>
          </div>
          {progress && <div className="rounded-md border border-slate-200 bg-slate-50 p-2 text-xs text-slate-700">{progress}</div>}
          {err && <div className="rounded-md border border-red-200 bg-red-50 p-2 text-xs text-red-700">{err}</div>}
        </div>
        <div className="flex justify-end gap-2 border-t border-slate-200 px-4 py-3">
          <button onClick={onClose} className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm">Cancel</button>
          <button onClick={saveAndSend} disabled={saving} className="inline-flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-1.5 text-sm text-white hover:bg-indigo-700 disabled:opacity-50">
            <Mail className="h-4 w-4" /> {saving ? "Sending…" : "Save & send email"}
          </button>
        </div>
      </div>
    </div>
  );
}

const PAGE_SIZE = 10;

function categoryOf(r: Row): { label: string; cls: string } {
  if (r.sameDay) return { label: "Same-Day", cls: "bg-sky-100 text-sky-800 border-sky-300" };
  if (r.dayDiff === 1) return { label: "1-Day Late", cls: "bg-amber-100 text-amber-800 border-amber-300" };
  return { label: "Different-Day", cls: "bg-rose-100 text-rose-800 border-rose-300" };
}

function PaginatedTable({ title, subtitle, rows, accent, onEdit, onRevert, onDownload, isChecked, onToggleDone, savingKey, showCategory, onBulkDone, bulkBusy }: { title: string; subtitle: string; rows: Row[]; accent: string; onEdit: (r: Row) => void; onRevert: (r: Row) => void; onDownload: () => void; isChecked: (r: Row) => boolean; onToggleDone: (r: Row, value: boolean) => void; savingKey: string | null; showCategory?: boolean; onBulkDone?: (rows: Row[]) => void; bulkBusy?: string | null }) {
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const p = Math.min(page, totalPages);
  const slice = rows.slice((p - 1) * PAGE_SIZE, p * PAGE_SIZE);
  const selectable = !!onBulkDone;
  const colCount = (showCategory ? 15 : 13) + (selectable ? 1 : 0);

  const toggle = (r: Row) => {
    const k = rowKey(r);
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(k)) next.delete(k); else next.add(k);
      return next;
    });
  };
  const allVisibleSelected = slice.length > 0 && slice.every((r) => selected.has(rowKey(r)));
  const toggleVisible = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (allVisibleSelected) slice.forEach((r) => next.delete(rowKey(r)));
      else slice.forEach((r) => next.add(rowKey(r)));
      return next;
    });
  };
  const selectAll = () => setSelected(new Set(rows.map(rowKey)));
  const clearAll = () => setSelected(new Set());
  const selectedRows = rows.filter((r) => selected.has(rowKey(r)));

  return (
    <div className={`rounded-lg bg-white p-4 shadow-sm border border-slate-200 ${accent}`}>
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-semibold text-slate-700">{title}</h3>
          <p className="text-xs text-slate-500">{subtitle}</p>
        </div>
        <button onClick={onDownload} disabled={rows.length === 0} className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40">
          <Download className="h-3.5 w-3.5" /> Download CSV
        </button>
      </div>

      {selectable && rows.length > 0 && (
        <div className="mb-3 flex flex-wrap items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-2">
          <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
            <input type="checkbox" checked={allVisibleSelected} onChange={toggleVisible} className="h-4 w-4 rounded border-slate-300" />
            This page
          </label>
          <button onClick={selectAll} className="rounded-md border border-slate-300 bg-white px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100">Select all ({rows.length})</button>
          <button onClick={clearAll} className="rounded-md border border-slate-300 bg-white px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100">Clear</button>
          <span className="text-xs text-slate-500">{selectedRows.length} selected</span>
          <button
            onClick={() => onBulkDone?.(selectedRows)}
            disabled={selectedRows.length === 0 || !!bulkBusy}
            className="ml-auto inline-flex items-center gap-1 rounded-md bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <CheckCheck className="h-3.5 w-3.5" /> {bulkBusy ? bulkBusy : `Mark ${selectedRows.length} done`}
          </button>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-left">
            <tr>
              {selectable && <Th><input type="checkbox" checked={allVisibleSelected} onChange={toggleVisible} className="h-4 w-4 rounded border-slate-300" title="Select this page" /></Th>}
              <Th>Status</Th>{showCategory && <Th>Category</Th>}<Th>Timestamp</Th><Th>Trainer</Th><Th>Under TL</Th><Th>Ticket ID</Th><Th>Corrected Date</Th><Th>Field</Th><Th>Incorrect</Th><Th>Correct</Th><Th>Zone</Th><Th>Reason</Th>{showCategory && <Th>Remark</Th>}<Th>Revert</Th><Th>Edit</Th>
            </tr>
          </thead>
          <tbody>
            {slice.map((r, i) => {
              const done = isChecked(r);
              const busy = savingKey === rowKey(r);
              const sel = selected.has(rowKey(r));
              return (
              <tr key={i} className={`border-b border-slate-100 hover:bg-slate-50 ${done ? "bg-emerald-50/60" : ""} ${sel ? "bg-indigo-50/50" : ""}`}>
                {selectable && (
                  <Td>
                    <input type="checkbox" checked={sel} onChange={() => toggle(r)} className="h-4 w-4 rounded border-slate-300" />
                  </Td>
                )}
                <Td>
                  <button
                    onClick={() => onToggleDone(r, !done)}
                    disabled={busy}
                    className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-xs font-medium disabled:opacity-50 ${done ? "border-emerald-300 bg-emerald-100 text-emerald-800" : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}
                    title={done ? "Undo done" : "Mark as checked & done"}
                  >
                    <Check className="h-3 w-3" /> {busy ? "…" : done ? "Done" : "Mark done"}
                  </button>
                </Td>
                {showCategory && (
                  <Td>
                    <span className={`inline-block rounded-full border px-2 py-0.5 text-[11px] font-medium ${categoryOf(r).cls}`}>{categoryOf(r).label}</span>
                  </Td>
                )}
                <Td>{r.timestamp}</Td>
                <Td className="whitespace-nowrap">{r.email}</Td>
                <Td>{r.tl}</Td>
                <Td className="font-mono">{r.ticket}</Td>
                <Td>{r.correctedDate}</Td>
                <Td>{r.field}</Td>
                <Td>{r.incorrect}</Td>
                <Td>{r.correct}</Td>
                <Td>{r.zone}</Td>
                <Td className="max-w-xs truncate" title={r.reason}>{r.reason}</Td>
                {showCategory && <Td className="max-w-[10rem] truncate" title={r.remark}>{r.remark || <span className="text-slate-400">—</span>}</Td>}
                <Td>
                  <button onClick={() => onRevert(r)} className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-xs font-medium ${r.revertSent ? "border-emerald-300 bg-emerald-50 text-emerald-800" : "border-indigo-300 bg-white text-indigo-700 hover:bg-indigo-50"}`} title={r.revertSent ? `Revert sent: ${r.revertSent}` : "Send revert to trainer"}>
                    <Mail className="h-3 w-3" /> {r.revertSent ? "Sent" : "Revert"}
                  </button>
                </Td>
                <Td>
                  <button onClick={() => onEdit(r)} className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-2 py-1 text-xs hover:bg-slate-50" title="Edit in Google Sheet">
                    <Pencil className="h-3 w-3" /> Edit
                  </button>
                </Td>
              </tr>
              );
            })}
            {slice.length === 0 && (
              <tr><td colSpan={colCount} className="p-6 text-center text-slate-500">No records</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <Pager page={p} totalPages={totalPages} total={rows.length} onChange={setPage} />
    </div>
  );
}

export function Pager({ page, totalPages, total, onChange }: { page: number; totalPages: number; total: number; onChange: (p: number) => void }) {
  if (total === 0) return null;
  const start = (page - 1) * PAGE_SIZE + 1;
  const end = Math.min(page * PAGE_SIZE, total);
  const windowSize = 5;
  const startPage = Math.max(1, page - 2);
  const endPage = Math.min(totalPages, startPage + windowSize - 1);
  const pages = [];
  for (let i = startPage; i <= endPage; i++) pages.push(i);

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 pt-3">
      <p className="text-xs text-slate-500">Showing {start}–{end} of {total}</p>
      <div className="flex flex-wrap gap-1">
        <PgBtn disabled={page === 1} onClick={() => onChange(page - 1)}>‹ Prev</PgBtn>
        {startPage > 1 && <><PgBtn onClick={() => onChange(1)}>1</PgBtn>{startPage > 2 && <span className="px-1 text-slate-400">…</span>}</>}
        {pages.map((n) => (
          <PgBtn key={n} active={n === page} onClick={() => onChange(n)}>{n}</PgBtn>
        ))}
        {endPage < totalPages && <>{endPage < totalPages - 1 && <span className="px-1 text-slate-400">…</span>}<PgBtn onClick={() => onChange(totalPages)}>{totalPages}</PgBtn></>}
        <PgBtn disabled={page === totalPages} onClick={() => onChange(page + 1)}>Next ›</PgBtn>
      </div>
    </div>
  );
}

function PgBtn({ children, active, disabled, onClick }: { children: React.ReactNode; active?: boolean; disabled?: boolean; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`rounded-md border px-2.5 py-1 text-xs font-medium transition ${
        active ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50"
      } disabled:opacity-40 disabled:cursor-not-allowed`}
    >
      {children}
    </button>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">{children}</th>;
}
function Td({ children, className = "", title }: { children: React.ReactNode; className?: string; title?: string }) {
  return <td className={`p-2 text-slate-700 ${className}`} title={title}>{children}</td>;
}
