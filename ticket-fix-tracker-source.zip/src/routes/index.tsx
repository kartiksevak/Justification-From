import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { useCorrections, toKey } from "@/lib/useCorrections";
import { DashboardShell, DateRangePicker, StatCard, Card } from "@/components/DashboardShell";
import { exportByTl, exportByZone } from "@/lib/exportCsv";
import { Download } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Overview,
  head: () => ({
    meta: [
      { title: "Overview · Trainer Corrections" },
      { name: "description", content: "Overview of trainer correction submissions with KPIs and breakdowns." },
      { property: "og:title", content: "Overview · Trainer Corrections" },
      { property: "og:description", content: "Overview of trainer correction submissions with KPIs and breakdowns." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const COLORS = ["#6366f1", "#ec4899", "#14b8a6", "#f59e0b", "#8b5cf6", "#ef4444", "#10b981", "#3b82f6", "#f97316", "#a855f7"];

function Overview() {
  const { rows, loading, error, lastUpdated, reload } = useCorrections();
  const [search, setSearch] = useState("");
  const [zoneFilter, setZoneFilter] = useState("all");
  const [tlFilter, setTlFilter] = useState("all");
  const [from, setFrom] = useState<Date | undefined>();
  const [to, setTo] = useState<Date | undefined>();

  const zones = useMemo(() => Array.from(new Set(rows.map((r) => r.zone).filter(Boolean))).sort(), [rows]);
  const tls = useMemo(() => Array.from(new Set(rows.map((r) => r.tl).filter(Boolean))).sort(), [rows]);

  const fromKey = toKey(from);
  const toK = toKey(to);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (zoneFilter !== "all" && r.zone !== zoneFilter) return false;
      if (tlFilter !== "all" && r.tl !== tlFilter) return false;
      if (fromKey && r.dateKey < fromKey) return false;
      if (toK && r.dateKey > toK) return false;
      if (!q) return true;
      return (
        r.ticket.toLowerCase().includes(q) ||
        r.email.toLowerCase().includes(q) ||
        r.field.toLowerCase().includes(q) ||
        r.reason.toLowerCase().includes(q)
      );
    });
  }, [rows, search, zoneFilter, tlFilter, fromKey, toK]);

  const perField = useMemo(() => {
    const m = new Map<string, number>();
    filtered.forEach((r) => r.field && m.set(r.field, (m.get(r.field) || 0) + 1));
    return Array.from(m, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [filtered]);

  const perZone = useMemo(() => {
    const m = new Map<string, number>();
    filtered.forEach((r) => r.zone && m.set(r.zone, (m.get(r.zone) || 0) + 1));
    return Array.from(m, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [filtered]);

  const sameDay = filtered.filter((r) => r.sameDay).length;
  const diffDay = filtered.length - sameDay;

  return (
    <DashboardShell lastUpdated={lastUpdated} loading={loading} onReload={reload}>
      {error && <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="🔍 Search Ticket ID, email, field, reason…"
          className="md:col-span-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
        />
        <select value={zoneFilter} onChange={(e) => setZoneFilter(e.target.value)} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="all">All Zones</option>
          {zones.map((z) => <option key={z} value={z}>{z}</option>)}
        </select>
        <select value={tlFilter} onChange={(e) => setTlFilter(e.target.value)} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="all">All TLs</option>
          {tls.map((z) => <option key={z} value={z}>{z}</option>)}
        </select>
      </div>
      <DateRangePicker from={from} to={to} onChange={(f, t) => { setFrom(f); setTo(t); }} />

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <StatCard label="Total Corrections" value={filtered.length} color="bg-indigo-600" />
        <StatCard label="Unique Trainers" value={new Set(filtered.map((r) => r.email)).size} color="bg-emerald-600" />
        <StatCard label="Unique Tickets" value={new Set(filtered.map((r) => r.ticket)).size} color="bg-amber-600" />
        <StatCard label="Same-Day" value={sameDay} color="bg-sky-600" />
        <StatCard label="Different-Day" value={diffDay} color="bg-rose-600" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-medium text-slate-700">Download report:</span>
        <button
          onClick={() => exportByTl(filtered)}
          className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-emerald-700"
        >
          <Download className="h-4 w-4" /> TL-wise CSV
        </button>
        <button
          onClick={() => exportByZone(filtered)}
          className="inline-flex items-center gap-1.5 rounded-md bg-amber-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-amber-700"
        >
          <Download className="h-4 w-4" /> Zone-wise CSV
        </button>
        <span className="text-xs text-slate-500">({filtered.length} rows in current filter)</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card title="Corrections by Field">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={perField} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(e) => `${e.name} (${e.value})`} fontSize={10}>
                {perField.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Corrections by Zone">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={perZone}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" fontSize={11} />
              <YAxis fontSize={11} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </DashboardShell>
  );
}
