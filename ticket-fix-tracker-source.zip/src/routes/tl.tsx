import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useCorrections, toKey } from "@/lib/useCorrections";
import { DashboardShell, DateRangePicker } from "@/components/DashboardShell";

export const Route = createFileRoute("/tl")({
  component: TlView,
  head: () => ({
    meta: [
      { title: "Under TL · Trainer Corrections" },
      { name: "description", content: "Corrections grouped by TL, showing each trainer's submission count." },
      { property: "og:title", content: "Under TL · Trainer Corrections" },
      { property: "og:description", content: "Corrections grouped by TL, showing each trainer's submission count." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function TlView() {
  const { rows, loading, error, lastUpdated, reload } = useCorrections();
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState<Date | undefined>();
  const [to, setTo] = useState<Date | undefined>();

  const fromKey = toKey(from);
  const toK = toKey(to);

  const grouped = useMemo(() => {
    const q = search.trim().toLowerCase();
    const map = new Map<string, Map<string, number>>();
    rows.forEach((r) => {
      if (fromKey && r.dateKey < fromKey) return;
      if (toK && r.dateKey > toK) return;
      if (q && !(`${r.tl} ${r.email}`.toLowerCase().includes(q))) return;
      const tl = r.tl || "— Unassigned —";
      if (!map.has(tl)) map.set(tl, new Map());
      const inner = map.get(tl)!;
      inner.set(r.email, (inner.get(r.email) || 0) + 1);
    });
    return Array.from(map.entries())
      .map(([tl, trainers]) => ({
        tl,
        total: Array.from(trainers.values()).reduce((s, v) => s + v, 0),
        trainers: Array.from(trainers.entries()).sort((a, b) => b[1] - a[1]),
      }))
      .sort((a, b) => b.total - a.total);
  }, [rows, search, fromKey, toK]);

  return (
    <DashboardShell lastUpdated={lastUpdated} loading={loading} onReload={reload}>
      {error && <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="🔍 Search TL or trainer email…"
          className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        />
        <DateRangePicker from={from} to={to} onChange={(f, t) => { setFrom(f); setTo(t); }} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {grouped.map((g) => (
          <div key={g.tl} className="rounded-lg bg-white shadow-sm border border-slate-200 border-l-4 border-l-indigo-500 p-3 flex flex-col">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="min-w-0">
                <p className="font-semibold text-slate-900 truncate" title={g.tl}>{g.tl}</p>
                <p className="text-xs text-slate-500">{g.trainers.length} trainer{g.trainers.length !== 1 ? "s" : ""}</p>
              </div>
              <span className="shrink-0 rounded-full bg-indigo-100 text-indigo-700 px-2.5 py-1 text-xs font-semibold">
                {g.total}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {g.trainers.map(([email, count]) => (
                <span
                  key={email}
                  title={email}
                  className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-700 max-w-full"
                >
                  <span className="truncate max-w-[160px]">{email}</span>
                  <span className="font-semibold text-indigo-700">{count}</span>
                </span>
              ))}
            </div>
          </div>
        ))}
        {grouped.length === 0 && !loading && (
          <div className="rounded-lg bg-white p-6 text-center text-slate-500 border border-slate-200 md:col-span-2 xl:col-span-3">No records</div>
        )}
      </div>
    </DashboardShell>
  );
}
