import { createFileRoute } from "@tanstack/react-router";
import { Fragment, useMemo, useState } from "react";
import { useCorrections, toKey, type Row } from "@/lib/useCorrections";
import { DashboardShell, DateRangePicker } from "@/components/DashboardShell";
import { Pager } from "./day-comparison";
import { ChevronDown, ChevronRight } from "lucide-react";

export const Route = createFileRoute("/changes")({
  component: Changes,
  head: () => ({
    meta: [
      { title: "Incorrect → Correct · Trainer Corrections" },
      { name: "description", content: "Aggregated view of most common incorrect-to-correct value changes with full ticket details." },
      { property: "og:title", content: "Incorrect → Correct · Trainer Corrections" },
      { property: "og:description", content: "Aggregated view of most common incorrect-to-correct value changes with full ticket details." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Agg = { field: string; incorrect: string; correct: string; count: number; rows: Row[] };
const PAGE_SIZE = 10;

function Changes() {
  const { rows, loading, error, lastUpdated, reload } = useCorrections();
  const [search, setSearch] = useState("");
  const [fieldFilter, setFieldFilter] = useState("all");
  const [from, setFrom] = useState<Date | undefined>();
  const [to, setTo] = useState<Date | undefined>();
  const [page, setPage] = useState(1);
  const [openKey, setOpenKey] = useState<string | null>(null);
  const [mode, setMode] = useState<"grouped" | "detailed">("grouped");

  const fields = useMemo(() => Array.from(new Set(rows.map((r) => r.field).filter(Boolean))).sort(), [rows]);
  const fromKey = toKey(from);
  const toK = toKey(to);

  const aggregated: Agg[] = useMemo(() => {
    const q = search.trim().toLowerCase();
    const m = new Map<string, Agg>();
    rows.forEach((r) => {
      if (!r.incorrect && !r.correct) return;
      if (fieldFilter !== "all" && r.field !== fieldFilter) return;
      if (fromKey && r.dateKey < fromKey) return;
      if (toK && r.dateKey > toK) return;
      if (q && !(`${r.field} ${r.incorrect} ${r.correct} ${r.ticket} ${r.email}`.toLowerCase().includes(q))) return;
      const key = `${r.field}||${r.incorrect}||${r.correct}`;
      const existing = m.get(key);
      if (existing) { existing.count++; existing.rows.push(r); }
      else m.set(key, { field: r.field, incorrect: r.incorrect, correct: r.correct, count: 1, rows: [r] });
    });
    return Array.from(m.values()).sort((a, b) => b.count - a.count);
  }, [rows, search, fieldFilter, fromKey, toK]);

  const detailed: Row[] = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (!r.incorrect && !r.correct) return false;
      if (fieldFilter !== "all" && r.field !== fieldFilter) return false;
      if (fromKey && r.dateKey < fromKey) return false;
      if (toK && r.dateKey > toK) return false;
      if (q && !(`${r.field} ${r.incorrect} ${r.correct} ${r.ticket} ${r.email} ${r.tl}`.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [rows, search, fieldFilter, fromKey, toK]);

  const list = mode === "grouped" ? aggregated : detailed;
  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  const p = Math.min(page, totalPages);
  const slice = list.slice((p - 1) * PAGE_SIZE, p * PAGE_SIZE);



  return (
    <DashboardShell lastUpdated={lastUpdated} loading={loading} onReload={reload}>
      {error && <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <input
          type="search"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          placeholder="🔍 Search field / value / ticket / email…"
          className="md:col-span-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        />
        <select value={fieldFilter} onChange={(e) => { setFieldFilter(e.target.value); setPage(1); }} className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="all">All Fields</option>
          {fields.map((f) => <option key={f} value={f}>{f}</option>)}
        </select>
      </div>
      <DateRangePicker from={from} to={to} onChange={(f, t) => { setFrom(f); setTo(t); setPage(1); }} />

      <div className="rounded-lg bg-white p-4 shadow-sm border border-slate-200 border-l-4 border-l-purple-500">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-slate-700">
              Incorrect → Correct Changes ({mode === "grouped" ? aggregated.length : detailed.length})
            </h3>
            <p className="text-xs text-slate-500">
              {mode === "grouped" ? "Click a row to see all tickets where this exact change was applied." : "Full detail — every ticket, trainer and change."}
            </p>
          </div>
          <div className="inline-flex rounded-md border border-slate-300 bg-white p-0.5 text-xs">
            <button onClick={() => { setMode("grouped"); setPage(1); }} className={`px-3 py-1 rounded ${mode === "grouped" ? "bg-indigo-600 text-white" : "text-slate-600"}`}>Grouped</button>
            <button onClick={() => { setMode("detailed"); setPage(1); }} className={`px-3 py-1 rounded ${mode === "detailed" ? "bg-indigo-600 text-white" : "text-slate-600"}`}>Detailed</button>
          </div>
        </div>
        <div className="overflow-x-auto">
          {mode === "grouped" ? (
            <table className="w-full text-sm">
              <thead className="bg-slate-100 text-left">
                <tr>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600 w-8"></th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600 w-12">#</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Field</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Incorrect Value</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Correct Value</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Sample Ticket / Trainer</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600 text-right">Count</th>
                </tr>
              </thead>
              <tbody>
                {(slice as Agg[]).map((a, i) => {
                  const key = `${a.field}||${a.incorrect}||${a.correct}`;
                  const open = openKey === key;
                  const sample = a.rows[0];
                  return (
                    <Fragment key={key}>
                      <tr className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer" onClick={() => setOpenKey(open ? null : key)}>
                        <td className="p-2 text-slate-400">{open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}</td>
                        <td className="p-2 text-slate-500">{(p - 1) * PAGE_SIZE + i + 1}</td>
                        <td className="p-2 text-slate-700">{a.field}</td>
                        <td className="p-2 text-rose-700">{a.incorrect || <span className="text-slate-400">—</span>}</td>
                        <td className="p-2 text-emerald-700">{a.correct || <span className="text-slate-400">—</span>}</td>
                        <td className="p-2 text-slate-700">
                          <div className="font-mono text-xs">{sample.ticket}</div>
                          <div className="text-xs text-slate-500">{sample.email}{a.count > 1 && <span className="text-slate-400"> +{a.count - 1} more</span>}</div>
                        </td>
                        <td className="p-2 text-right font-semibold text-slate-900">{a.count}</td>
                      </tr>
                      {open && (
                        <tr key={key + "-detail"}>
                          <td colSpan={7} className="p-0 bg-slate-50">
                            <div className="p-3">
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="text-left text-slate-500">
                                    <th className="p-1.5 font-semibold">Ticket ID</th>
                                    <th className="p-1.5 font-semibold">Trainer</th>
                                    <th className="p-1.5 font-semibold">Under TL</th>
                                    <th className="p-1.5 font-semibold">Zone</th>
                                    <th className="p-1.5 font-semibold">Timestamp</th>
                                    <th className="p-1.5 font-semibold">Corrected Date</th>
                                    <th className="p-1.5 font-semibold">Reason</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {a.rows.map((r, j) => (
                                    <tr key={j} className="border-t border-slate-200">
                                      <td className="p-1.5 font-mono text-slate-700">{r.ticket}</td>
                                      <td className="p-1.5 text-slate-700">{r.email}</td>
                                      <td className="p-1.5 text-slate-700">{r.tl}</td>
                                      <td className="p-1.5 text-slate-700">{r.zone}</td>
                                      <td className="p-1.5 text-slate-600">{r.timestamp}</td>
                                      <td className="p-1.5 text-slate-600">{r.correctedDate}</td>
                                      <td className="p-1.5 text-slate-600 max-w-xs truncate" title={r.reason}>{r.reason}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
                {slice.length === 0 && (
                  <tr><td colSpan={7} className="p-6 text-center text-slate-500">No changes match filters</td></tr>
                )}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-100 text-left">
                <tr>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600 w-12">#</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Ticket ID</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Trainer</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Under TL</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Field</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Incorrect</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Correct</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Zone</th>
                  <th className="p-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {(slice as Row[]).map((r, i) => (
                  <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="p-2 text-slate-500">{(p - 1) * PAGE_SIZE + i + 1}</td>
                    <td className="p-2 font-mono text-slate-700">{r.ticket}</td>
                    <td className="p-2 text-slate-700">{r.email}</td>
                    <td className="p-2 text-slate-700">{r.tl}</td>
                    <td className="p-2 text-slate-700">{r.field}</td>
                    <td className="p-2 text-rose-700">{r.incorrect}</td>
                    <td className="p-2 text-emerald-700">{r.correct}</td>
                    <td className="p-2 text-slate-700">{r.zone}</td>
                    <td className="p-2 text-slate-600">{r.timestamp}</td>
                  </tr>
                ))}
                {slice.length === 0 && (
                  <tr><td colSpan={9} className="p-6 text-center text-slate-500">No changes match filters</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>
        <Pager page={p} totalPages={totalPages} total={list.length} onChange={setPage} />
      </div>
    </DashboardShell>
  );
}
