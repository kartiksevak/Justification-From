# Roadmap

- [x] Hide remarks only from the three pending correction lists
- [x] Add mailbox-style Email Activity with complete message reading
- [x] Verify list visibility and opening a real message

- [x] Move correction reload behind the server connection with a published-sheet fallback
- [x] Keep cached rows visible while refreshing
- [x] Add bounded retry for temporary Gmail failures
- [x] Report sheet-save and email-send results separately
- [x] Verify live correction reload and preview build
- [x] Trainer Counts CSV: field breakdown as separate columns
- [x] Handle Google Sheets 429 (quota) — cache + retry with backoff
- [x] Same vs Different Day: filter by Incorrect value
- [x] Same vs Different Day: filter by Select Field to be Corrected
